from __future__ import annotations

from typing import List, Optional, Union

import pydantic

from databricks.data_monitoring import const


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class Snapshot:
    """Snapshot-based analysis type spec for generic data."""
    pass


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class TimeSeries:
    """Analysis type spec for time series data."""

    timestamp_col: str
    """
    Column that contains the timestamp of each row. The column must be one of the following:

      - A ``TimestampType`` column, or
      - A column whose values can be converted to timestamps through the pyspark
        ``to_timestamp`` `function <https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.functions.to_timestamp.html>`_.
    """

    granularities: List[str]
    """
    Granularities for aggregating data into time windows based on their timestamp. Currently the following static 
    granularities are supported:
    {``"5 minutes"``, ``"30 minutes"``, ``"1 hour"``, ``"1 day"``, ``"<n> week(s)"``, ``"1 month"``, ``"1 year"``}.
    """


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class InferenceLog:
    """
    Analysis type spec for ML inference data.
    """

    timestamp_col: str
    """
    Column that contains the timestamps of requests. The column must be one of the following:

      - A ``TimestampType`` column
      - A column whose values can be converted to timestamps through the pyspark
        ``to_timestamp`` `function <https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.functions.to_timestamp.html>`_.
    """

    granularities: List[str]
    """
    Granularities for aggregating data into time windows based on their timestamp. Currently the following static 
    granularities are supported:
    {``"5 minutes"``, ``"30 minutes"``, ``"1 hour"``, ``"1 day"``, ``"<n> week(s)"``, ``"1 month"``, ``"1 year"``}.
    """

    model_id_col: str
    """
    Column that contains the id of the model generating the predictions. Metrics will be computed per model id by 
    default, and also across all model ids. 
    """

    problem_type: str
    """
    One of ``"regression"`` or ``"classification"``. Determines the type of model-quality metrics that will be computed. 
    """

    prediction_col: str
    """Column that contains the output/prediction from the model."""

    label_col: Optional[str] = None
    """Optional column that contains the ground-truth for the prediction."""

    prediction_proba_col: Optional[str] = None
    """
    Optional column that contains the prediction probabilities for each class in a classification problem type. 
    The values in this column should be a map, mapping each class label to the prediction probability for a given 
    sample. The map should be of PySpark MapType().
    """


Analysis = Union[Snapshot, TimeSeries, InferenceLog]
