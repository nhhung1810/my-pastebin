"""
Utility methods for tables, (UC) schemas, and catalogs.
"""
import abc
import copy
import logging
import re
import string
from typing import Iterable, Optional, Set, Tuple, Union

from pyspark import sql
from pyspark.sql import functions as F, types as T, utils as pyspark_utils

from databricks.data_monitoring import const, errors, metadata, analysis, utils
from databricks.data_monitoring.context import Context
from databricks.data_monitoring.const import JobRunMetricsConstants

_AUTO_MERGE_SPARK_CONF = "spark.databricks.delta.schema.autoMerge.enabled"


class SecurableName(abc.ABC):
    """
    Abstract base class for securable names. The class enforces the convention that UC securable names are
    lower-case (https://docs.databricks.com/en/sql/language-manual/sql-ref-names.html#names).
    """

    @property
    @abc.abstractmethod
    def parent(self) -> Optional["SecurableName"]:
        """
        Returns the parent (if any) as a SecurableName (e.g., for "a.b.c" this returns the securable name for "a.b")
        """
        pass

    @abc.abstractmethod
    def _name_impl(self) -> str:
        """
        Returns the "leaf" name of the securable (e.g., "C" if the securable is "a.b.C"). This is a separate method
        so that we can wrap it in a `lower()` call in the public method.
        """
        pass

    @property
    def name(self) -> str:
        """Returns the lower-case "leaf" name of the securable (e.g., "c" if the securable is "a.b.c")"""
        return self._name_impl().lower()

    @property
    def fully_qualified_name(self) -> str:
        """Returns the lower-case fully-qualified name of the securable (e.g., "a.b.c")"""
        return self.name if self.parent is None else f"{self.parent.fully_qualified_name}.{self.name}"

    @property
    def delimited_name(self) -> str:
        """Returns the lower-case leaf name of the securable but in delimited form (e.g., "`c`")"""
        return utils.delimited_identifier(self.name)

    @property
    def fully_qualified_delimited_name(self) -> str:
        """Returns the fully-qualified lower-case name of the securable but in delimited form (e.g., "`a`.`b`.`c`")"""
        return (self.delimited_name if self.parent is None else
                f"{self.parent.fully_qualified_delimited_name}.{self.delimited_name}")

    def __eq__(self, other):
        if not isinstance(other, SecurableName):
            return False

        other_securable: SecurableName = other
        return self.fully_qualified_delimited_name == other_securable.fully_qualified_delimited_name


class CatalogName(SecurableName):
    """
    Captures information about a catalog name.
    """

    def __init__(self, catalog_name: str) -> None:
        """
        Initializes a CatalogName instance. Note that we remove a single-set of enclosing
        backticks and "un-escape" extra backticks in the catalog name.
        :param catalog_name:
        """
        self._name = utils.dedelimited_identifier(catalog_name)

    def _name_impl(self) -> str:
        return self._name

    @property
    def parent(self) -> Optional[SecurableName]:
        return None


class SchemaName(SecurableName):
    """
    Captures information about a schema name.
    """

    @classmethod
    def _parse_schema_name(cls, name: Optional[str], primary_schema_name: Optional["SchemaName"]
                           ) -> Tuple[str, str, bool, bool]:
        """
        Parses the provided schema name and returns the catalog and the schema name, and booleans to indicate whether
        the catalog and schema were autocompleted from the current defaults. The input parameter and the parsing
        rules are as follows:
        - Fully qualified with catalog, like "{catalog}.{schema}" ==> Return (catalog, schema, False, False)
        - Not qualified, e.g., "{schema}" ==> Return (default catalog, schema, True, False)
        - None ==> Return (default catalog, default schema, True, True)
        Raises an error if the input is not of a supported format.
        :param name: The (partially- or fully-qualified) name of the schema
        :param primary_schema_name: The fully qualified primary table schema used to autocomplete the schema if provided
        :return: The catalog and schema name and two booleans indicating whether the default catalog and schema are
          selected.
        """
        default_catalog = primary_schema_name.catalog_name.name if primary_schema_name else Context.current_catalog
        default_schema = primary_schema_name.name if primary_schema_name else Context.current_schema_name

        if not name:
            return default_catalog, default_schema, True, True

        parts = name.split(".")
        if len(parts) > 2:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.INVALID_SCHEMA_NAME_FORMAT, name=name)

        if len(parts) == 1:
            return default_catalog, name, True, False
        else:
            return parts[0], parts[1], False, False

    def __init__(self,
                 input_spec: Optional[Union[str, Tuple[str, str]]],
                 primary_schema_name: Optional["SchemaName"] = None) -> None:
        """
        Initializes a SchemaName instance. Note that we remove a single-set of enclosing backticks
        and "un-escape" extra backticks in each securable.
        :param input_spec: There are three options for the input:

          - ``None``: Initializes to the current schema from the Context
          - str: Initializes from a partially or fully qualified name
          - Tuple[str, str]: Initializes from (catalog, schema) tuple
        :param primary_schema_name: The fully qualified primary table schema used to autocomplete the schema if provided
        """
        self._primary_schema_name = primary_schema_name
        if input_spec is None or isinstance(input_spec, str):
            catalog, name, self._catalog_autocompleted, self._schema_autocompleted = self._parse_schema_name(
                input_spec, primary_schema_name)
            self._init_name = input_spec
        elif isinstance(input_spec, tuple):
            catalog = input_spec[0]
            name = input_spec[1]
            self._schema_autocompleted = False
            self._catalog_autocompleted = False
            self._init_name = f"{catalog}.{name}"
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.INVALID_SCHEMA_NAME_FORMAT,
                name=input_spec)

        self._catalog_name = CatalogName(catalog)
        self._name = utils.dedelimited_identifier(name)

    def warn_if_autocompleted(self, logger: logging.Logger, param_name: str) -> None:
        """
        Prints out warning messages in the logger if any parts of the schema name are autocompleted.
        :param logger: The logger to print the warning messages to
        :param param_name: The name of the parameter that the schema name is used for
        """
        if not self._catalog_autocompleted:
            return

        catalogAutocompleteMsg = "catalog of the primary table" if self._primary_schema_name else "default catalog"
        schemaAutocompleteMsg = "schema of the primary table" if self._primary_schema_name else "default schema"

        if self._schema_autocompleted:
            logger.warning(
                f"Lakehouse Monitoring used the {catalogAutocompleteMsg} "
                f"'{self.catalog_name.name}' and {schemaAutocompleteMsg} '{self.name}' to fill for an unspecified "
                f"schema name in the parameter '{param_name}'. You can use the fully-qualified schema name "
                "or switch the default catalog with the SQL command `USE CATALOG` and the default schema with "
                "`USE SCHEMA`.")
        else:
            logger.warning(
                f"Lakehouse Monitoring used the {catalogAutocompleteMsg} "
                f"'{self.catalog_name.name}' to look for the "
                f"schema `{self._init_name}` in the parameter '{param_name}'. You can use the fully-qualified schema "
                "name or switch the default catalog with the SQL command `USE CATALOG`.")

    @property
    def catalog_name(self) -> CatalogName:
        return self._catalog_name

    def _name_impl(self) -> str:
        return self._name

    @property
    def parent(self) -> Optional[SecurableName]:
        return self._catalog_name


class TableName(SecurableName):
    """
    Captures information about a table name.
    """

    @classmethod
    def _parse_table_name(cls, table_name: str) -> Tuple[str, str, str, bool, bool]:
        """
        Parses the table name to return the catalog, schema, and table name, and booleans to indicate whether catalog
          and schema were autocompleted
        :param table_name: The name of the table. Qualified names:
                            - Can be qualified with catalog and schema like "{catalog}.{schema}.{table}". or
                            - Can be qualified with schema, like "{schema}.{table}", or
                            - Can be qualified with just table name, like "{table}".

        :return: a (catalog, schema, table) tuple of names
        """
        parts = table_name.split(".")
        if len(parts) > 3:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.INVALID_TABLE_NAME_FORMAT,
                table_name=table_name)

        if len(parts) == 1:
            catalog = Context.current_catalog
            catalog_autocomplete = True
            schema = Context.current_schema_name
            schema_autocomplete = True
            name = parts[0]
        elif len(parts) == 2:
            catalog = Context.current_catalog
            catalog_autocomplete = True
            schema_autocomplete = False
            schema, name = parts
        else:  # len(parts) == 3
            catalog_autocomplete = False
            schema_autocomplete = False
            catalog, schema, name = parts

        return catalog, schema, name, catalog_autocomplete, schema_autocomplete

    def __init__(self, table_name: str) -> None:
        """
        Initializes a TableName instance. Note that we remove a single-set of enclosing backticks
        and "un-escape" extra backticks in each securable.
        :param table_name: partially or fully qualified name of table
        """
        self._init_name = table_name
        catalog, schema, name, self._catalog_autocompleted, self._schema_autocompleted = self._parse_table_name(
            table_name)

        self._catalog_name = CatalogName(catalog)
        self._schema_name = SchemaName((catalog, schema))
        self._name = utils.dedelimited_identifier(name)

    @property
    def catalog_name(self) -> CatalogName:
        return self._catalog_name

    @property
    def schema_name(self) -> SchemaName:
        return self._schema_name

    def _name_impl(self) -> str:
        return self._name

    @property
    def parent(self) -> Optional[SecurableName]:
        return self._schema_name

    def warn_if_autocompleted(self, logger: logging.Logger) -> None:
        """Prints out warning messages in the logger if any parts of the table name are autocompleted."""
        if self._schema_autocompleted:
            logger.warning(
                "Lakehouse Monitoring used the default catalog "
                f"`{self.catalog_name.name}` and default schema "
                f"`{self.schema_name.name}` to look for the "
                f"table `{self._init_name}`. If this is wrong then you can use the fully-qualified "
                "table name or switch the default catalog with the SQL command "
                "`USE CATALOG` and the default schema with the SQL "
                "command `USE SCHEMA`.")
        elif self._catalog_autocompleted:
            logger.warning(
                "Lakehouse Monitoring used the default catalog "
                f"'{self.catalog_name.name}' to look for the "
                f"table `{self._init_name}`. If this is wrong then you can use the fully-qualified "
                "table name or switch the default catalog with the SQL command `USE CATALOG`.")


def sanitize(name: str) -> str:
    """
    Sanitizes the input name by substituting illegal chars (for table naming) with "_",
    and converts to lowercase per saveAsTable API behavior.
    :param name: The input name
    :return: The lowercase sanitized name
    """
    return re.sub(f"[{string.punctuation}{string.whitespace}]", "_", name).lower()


def table_name_prefix(model_name: str, monitor_name: str, schema_name: Optional[str] = None) -> str:
    """
    Returns the table name prefix. Model and monitor names will be sanitized before generating the
    table name prefix.
    :param schema_name: Schema that contains the table.
    :param model_name: Model name before sanitization.
    :param monitor_name: Monitor name before sanitization.
    :return: Table name prefix.
    """
    sanitized_model_name = sanitize(model_name)
    sanitized_monitor_name = sanitize(monitor_name)
    if not schema_name:
        return f"{sanitized_model_name}_{sanitized_monitor_name}"
    else:
        return f"{schema_name}.{sanitized_model_name}_{sanitized_monitor_name}"


def grant_all_privileges(table_name: TableName, principal: str) -> None:
    """
    Grants `ALL PRIVILEGES` to the given table for a given principal.
    This method works if the table is unqualified, qualified by schema, or
    qualified by catalog and schema.

    Note that this grant will fail if the cluster does not have Table ACLs enabled.

    :param table_name: Table name to grant privileges on
    :param principal: A user or group to grant `ALL PRIVILEGES` to
    :return: None
    """
    Context.spark.sql(
        f"GRANT ALL PRIVILEGES ON TABLE {table_name.fully_qualified_delimited_name} TO `{principal}`"
    )


def get_baseline_data(info: metadata.MonitorInfo, model_id: Optional[str]) -> sql.DataFrame:
    """
    Returns the baseline data of a specific model version, or the entire baseline table if None.
    Throws errors if:
    - If the baseline table is not set
    - `model_id` is set and the analysis_type in the metadata does not have the notion of a model ID

    :param info: the metadata of the monitor that the baseline was logged to.
    :param model_id: The ID of the model that the baseline was associated with. If None, the
                          entire baseline table will be returned.
    :return: a pyspark dataframe representing the baseline data for the model version.
    """
    if model_id is not None and not isinstance(info.profile_type, analysis.InferenceLog):
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
            message="Incompatible analysis type when retrieving the baseline based on model version")

    if info.baseline_table_name is None:
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.EMPTY_BASELINE_DATA)

    baseline_df = Context.spark.table(info.baseline_table_name)
    if model_id is None:
        return baseline_df

    return baseline_df.filter(F.col(info.profile_type.model_id_col) == model_id)


def calculate_schema_difference(schema_a: T.StructType,
                                schema_b: T.StructType,
                                ignore_fields: Set[str] = frozenset()
                                ) -> Set[Tuple[str, T.DataType]]:
    """
    Returns the set of fields that are present in schema A and
    missing from schema B. Note that it does not consider:
        - The provided ignore_fields
        - Fields in schema B that are missing from schema A
        - The nullability of a field when comparing across the two schemas

    :param schema_a: Schema A
    :param schema_b: Schema B
    :param ignore_fields: A set of column names to ignore from the schema diff
    :return: set of (name, data type) tuples in Schema A missing from Schema B
    """
    a_fields = {(f.name, f.dataType) for f in schema_a.fields if f.name not in ignore_fields}
    b_fields = {(f.name, f.dataType) for f in schema_b.fields if f.name not in ignore_fields}

    return a_fields - b_fields


def is_fully_qualified_schema_name(name: str) -> bool:
    """
    Checks the given schema name is indeed fully qualified

    :param name: schema name
    :return: True if the given name is a 2 level schema name, False otherwise
    """
    parts = name.split(".")
    return len(parts) == 2


def create_table(table_name, schema) -> None:
    """
    Creates an empty table given the table name and the schema.
    Will raise error if table already exists.

    :param table_name: The name of the table.
    :param schema: the schema of the table.
    :return: None.
    """
    try:
        df = Context.spark.createDataFrame(data=[], schema=schema)
        df.write.format("delta").mode("errorifexists").saveAsTable(table_name)
    except pyspark_utils.AnalysisException as ae:
        # Notes: Different DBR versions raise different error msg when table exists.
        # There is a chance that this may not catch all the table exists cases.
        if "already exists" in str(ae):
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.TABLE_FOUND,
                table_name=table_name,
                msg="The monitor cannot be created because the output tables already exist. "
                "This could be because a monitor for this table already exists (only one can exist per table), "
                "or because the output table name is already in use. For the latter case, you can provide a "
                "different `output_schema_name` to resolve the issue.")
        else:
            raise ae


def drop_table(table_name):
    """
    Drop the table if it exists.

    :param table_name: the name of the table.
    :return: None
    """
    Context.spark.sql(f"DROP TABLE IF EXISTS {table_name}")


def upsert_into_table(target_table_name: TableName, source_df: sql.DataFrame,
                      row_id_cols: Iterable[str]) -> None:
    """
    Upserts a DataFrame into a target table:
        - If a row in `source_df` has ID column values that match a row in the table, it gets updated
        - If a row in `source_df` has ID column values not yet in the table, it gets inserted
        - Existing rows in the table are unmodified

    :param target_table_name: 3L qualified name of the target table to write to
    :param source_df: DataFrame containing data to write. Schema should exactly match the target table.
    :param row_id_cols: Iterable of column names that uniquely identify a row. Used in the merge
                        condition for a null-safe equi-join on the existing table rows.
    :return: None
    """
    if not Context.uc_client.table_exists(target_table_name.fully_qualified_name):
        source_df.write.format("delta").mode("overwrite").saveAsTable(
            target_table_name.fully_qualified_delimited_name)
    else:
        # Upsert will fail if the schemas are different, so we make sure schemas are compatible
        # Note that we do not use automatic schema merging via the
        # spark.databricks.delta.schema.autoMerge.enabled property, since it has
        # erroneous behavior when upserting struct columns with nulls.
        # See https://databricks.atlassian.net/browse/SC-78419 for more details.
        target_df = Context.spark.table(target_table_name.fully_qualified_delimited_name)
        target_schema = target_df.schema
        source_schema = source_df.schema

        # Note that calculate_schema_difference cannot tell when a struct column's schema
        # has evolved, and overall our schema widening does not support widening struct schemas,
        # i.e. this will fail during merge if the source data struct has a new field
        # that the target table struct does not have.
        missing_from_table = calculate_schema_difference(source_schema, target_schema)
        missing_from_data = calculate_schema_difference(target_schema, source_schema)

        # Widen the existing data
        for f_name, f_data_type in missing_from_table:
            target_df = target_df.withColumn(f_name, F.lit(None).cast(f_data_type))

        # Widen the upsert data with dummy values (note we will not use these nulls, but
        # the columns need to exist so the schemas match when we try to upsert).
        for f_name, f_data_type in missing_from_data:
            source_df = source_df.withColumn(f_name, F.lit(None).cast(f_data_type))

        # Filter rows from the target data that match rows from the source data, where
        # "match" is defined by equality on all row ID columns.
        join_condition = F.expr(" AND ".join(
            [f"existing.{col} <=> updated.{col}" for col in row_id_cols]))
        target_df = target_df.alias("existing").join(
            source_df.alias("updated"), on=join_condition, how="left_anti")

        # Perform the union and write the results
        source_df.unionByName(target_df).write.format("delta").mode("overwrite").option(
            "overwriteSchema", "true").saveAsTable(target_table_name.fully_qualified_delimited_name)


# TODO(ML-27362): Unify the way to get output table context columns schema.
def profile_table_context_columns_schema(analysis_type: analysis.Analysis,
                                         input_table_schema: T.StructType):
    """Generates the schema of the columns in the profile table that define the context of the metrics."""
    schema = copy.deepcopy(const.BASIC_PROFILE_TABLE_CONTEXT_COLUMNS_SCHEMA)
    if isinstance(analysis_type, analysis.InferenceLog):
        schema.add(input_table_schema[analysis_type.model_id_col])
    return schema


def drift_table_context_columns_schema(analysis_type: analysis.Analysis,
                                       input_table_schema: T.StructType):
    """Generates the schema of the columns in the drift table that define the context of the metrics."""
    schema = copy.deepcopy(const.BASIC_DRIFT_TABLE_CONTEXT_COLUMNS_SCHEMA)
    if isinstance(analysis_type, analysis.InferenceLog):
        schema.add(input_table_schema[analysis_type.model_id_col])
    return schema


def get_table_size(fully_qualified_table_name: str) -> Optional[int]:
    """
    Returns the size of a given table (in bytes). Note that it is not possible to compute the size
    of a view or materialized view.

    :param fully_qualified_table_name:
    :return: size of table in bytes or None if size is not available
    """
    try:
        return Context.spark.sql(JobRunMetricsConstants.TABLE_SIZE_QUERY_PREFIX +
                                 fully_qualified_table_name).select(
                                     JobRunMetricsConstants.TABLE_SIZE_COLUMN).first()[
                                         JobRunMetricsConstants.TABLE_SIZE_COLUMN]
    except:
        # pyspark_utils.AnalysisException is raised because views which are not supported by
        # `describe detail` or if the table name is invalid. We catch all exceptions here to avoid
        # unforseen errors affecting the profiling logic.
        return None
