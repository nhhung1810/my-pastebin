import re
from typing import Optional

from databricks.data_monitoring import const


def delimited_identifier(identifier: Optional[str]) -> Optional[str]:
    """
    Returns the delimited version of an identifier based on
    https://docs.databricks.com/en/sql/language-manual/sql-ref-identifiers.html
    :param identifier:
    :return: The identifier enclosed in backticks, with ``` escaped as a special character.
    """
    if identifier is None:
        return None

    quoted_id = identifier.replace("`", "``")
    return f"`{quoted_id}`"


def dedelimited_identifier(identifier: Optional[str]) -> Optional[str]:
    """
    Undoes the delimited identifier operation. Examples:
    - "catalog" => "catalog"
    - "`catalog`" => "catalog"
    - "```table```" => "`table`"
    - "`schema```" => "schema`"

    :param identifier:
    :return: The identifier with stripped enclosing backticks, and unescaped backticks.
    """
    if identifier is None:
        return None

    pattern = r"^`(.*)`$"
    match = re.match(pattern, identifier)
    return (match.group(1) if match else identifier).replace("``", "`")


class ColumnName(str):
    """
    Class for passing around column names in the profiling pipeline.
    """

    def __str__(self) -> str:
        return dedelimited_identifier(super().__str__())

    @property
    def delimited_name(self) -> str:
        """
        Returns the delimited version of the column name, useful for handling column names with special
        characters like dots in pyspark operations. Note, the constant column names defined in `ProfileTableConstants`
        and the wild card keyword "*" are not backquoted.
        """
        profile_table_constant_cols = [
            v for (k, v) in vars(const.ProfileTableConstants).items() if not k.startswith("__")
        ]
        if self.__str__() in profile_table_constant_cols + [const.ALL_COLUMN_INPUT_NAME]:
            return self.__str__()
        return delimited_identifier(self.__str__())
