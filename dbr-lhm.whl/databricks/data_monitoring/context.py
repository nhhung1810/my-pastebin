"""
Introduces main Context class and the framework to specify different specialized
contexts.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

from pyspark import sql

from databricks.data_monitoring import errors
from databricks.data_monitoring.clients import (base_monitoring_service_client, uc_client,
                                                redash_client)


class ContextMeta(ABC.__class__):
    """
    Metaclass for Context to allow setting the current context instance.
    """

    def __init__(cls, *args, **kwargs):
        super().__init__(*args, **kwargs)
        cls._current = None

    @property
    def active(cls) -> bool:
        return cls._current is not None

    @property
    def current(cls) -> Any:
        if not cls.active:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.NO_AVAILABLE_CONTEXT)
        return cls._current

    @current.setter
    def current(cls, context) -> None:
        if context is not None and cls.active:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.CONTEXT_ALREADY_SET)
        cls._current = context

    @property
    def spark(cls) -> sql.SparkSession:
        return cls.current.get_spark()

    @property
    def service_client(cls) -> base_monitoring_service_client.MonitoringServiceClient:
        return cls.current.get_service_client()

    @property
    def uc_client(cls) -> uc_client.UcClient:
        return cls.current.get_uc_client()

    @property
    def redash_client(cls) -> redash_client.RedashClient:
        return cls.current.get_redash_client()

    @property
    def current_schema_name(cls) -> str:
        return cls.current.get_current_schema_name()

    @property
    def current_catalog(cls) -> str:
        return cls.current.get_current_catalog()

    @property
    def user_name(cls) -> str:
        return cls.current.get_user_name()

    def display_html(cls, html: str) -> None:
        cls.current.display_html(html)

    def clear(cls) -> None:
        cls.current.clear_context()
        cls.current = None

    @property
    def job_id(cls) -> Optional[str]:
        return cls.current.get_job_id()

    @property
    def run_id(cls) -> Optional[str]:
        return cls.current.get_run_id()


class Context(ABC, metaclass=ContextMeta):
    """
    Abstract class for Data Monitoring execution context.
    """

    @abstractmethod
    def get_spark(self) -> sql.SparkSession:
        pass

    @abstractmethod
    def get_service_client(self) -> base_monitoring_service_client.MonitoringServiceClient:
        pass

    @abstractmethod
    def get_uc_client(self) -> uc_client.UcClient:
        pass

    @abstractmethod
    def get_redash_client(self) -> redash_client.RedashClient:
        pass

    def get_current_schema_name(self) -> str:
        """
        Get the current schema, which is guaranteed to exist.
        :return: The name of the schema within the current catalog (i.e., not fully qualified)
        """
        return self.get_spark().sql("SELECT current_schema() AS schema").collect()[0]["schema"]

    def get_current_catalog(self) -> str:
        """
        Get the current catalog, which is guaranteed to exist.
        :return: The name of the catalog.
        """
        return self.get_spark().sql("SELECT current_catalog() AS catalog").collect()[0]["catalog"]

    @abstractmethod
    def get_user_name(self) -> str:
        pass

    @abstractmethod
    def clear_context(self) -> None:
        pass

    @abstractmethod
    def uc_enabled(self) -> bool:
        pass

    @abstractmethod
    def get_job_id(self) -> Optional[str]:
        pass

    @abstractmethod
    def get_run_id(self) -> Optional[str]:
        pass
