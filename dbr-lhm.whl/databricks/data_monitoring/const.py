"""Module of const values for data monitoring package."""

from enum import Enum

from pyspark.sql import types as T
import pydantic


class PydanticConfig:
    """Internal config used to allow arbitrary types and prevent extra args from being passed
    into pydantic dataclasses"""
    arbitrary_types_allowed = True
    extra = pydantic.Extra.forbid


class MlflowPermissionLevel(str, Enum):
    """
    MLflow model permission levels as defined by
    https://docs.databricks.com/dev-tools/api/latest/mlflow.html#operation/get-registered-model
    """
    CAN_MANAGE = "CAN_MANAGE"
    CAN_READ = "CAN_READ"
    CAN_EDIT = "CAN_EDIT"
    CAN_MANAGE_STAGING_VERSIONS = "CAN_MANAGE_STAGING_VERSIONS"
    CAN_MANAGE_PRODUCTION_VERSIONS = "CAN_MANAGE_PRODUCTION_VERSIONS"


class JobRunMetricsConstants:
    """Constants representing column names and queries for collecting job run metrics."""

    # Query prefix used to get the size of a table in bytes.
    TABLE_SIZE_QUERY_PREFIX = "DESCRIBE DETAIL "
    # Column used to track the size of the table in bytes.
    TABLE_SIZE_COLUMN = "sizeInBytes"


class RefreshBootstrapInfoFields:
    """
    Field names of refresh bootstrap info, as passed in by the entry wheel.
    """
    FULLY_QUALIFIED_TABLE_NAME = "fully_qualified_table_name"
    PROFILING_CONFS = "profiling_confs"


# Metric type
class MetricType(str, Enum):
    AGGREGATE = "aggregate"
    DERIVED = "derived"
    DRIFT = "drift"


# Keep in sync with ProblemType enum variable in proto definitions
class ProblemType(str, Enum):
    CLASSIFICATION = "classification"
    REGRESSION = "regression"


# Type of tables that can be handled by monitoring
class TableType(str, Enum):
    DELTA_TABLE = "Delta Table"
    LOGICAL_VIEW = "Logical View"
    OTHER = "Unsupported table type"


class ClassificationMetricOutputFields:
    """
    Struct field names and data types for classification metrics with different averaging methods.
    """
    ONE_VS_ALL_FIELD_NAME = "one_vs_all"
    MACRO_FIELD_NAME = "macro"
    WEIGHTED_FIELD_NAME = "weighted"

    ONE_VS_ALL_FIELD_TYPE = T.MapType(T.StringType(), T.DoubleType())
    AVERAGING_METRIC_OUTPUT_TYPE = T.StructType([
        T.StructField(ONE_VS_ALL_FIELD_NAME, ONE_VS_ALL_FIELD_TYPE),
        T.StructField(MACRO_FIELD_NAME, T.DoubleType()),
        T.StructField(WEIGHTED_FIELD_NAME, T.DoubleType())
    ])


class FairnessMetricComparisonMethod(str, Enum):
    DIFFERENCE = "difference"
    RATIO = "ratio"


# Name associated with all columns in the input table, will not appear
# as "column_name" in the profile table
ALL_COLUMN_INPUT_NAME = "*"


class ProfileTableConstants:
    """Constants representing column names in the profile tables."""

    # Name associated with table level inputs, stored as "column_name" in the profile table
    TABLE_INPUT_NAME = ":table"
    # Column used to store time window grouping
    WINDOW_COLUMN = "window"
    # Column used to store comparison time window (for drift metrics)
    CMP_WINDOW_COLUMN = "window_cmp"
    # Column used to track the granularity of the time window grouping
    GRANULARITY_COLUMN = "granularity"
    # Column used to track the type of analyzed data
    LOG_TYPE_COLUMN = "log_type"
    # Column used to differentiate type of drift comparison
    DRIFT_TYPE = "drift_type"
    # Column used to indicate the input column name a row contains metrics for
    INPUT_COLUMN_NAME = "column_name"
    # Column used to indicate the input column value during melted analysis
    MELTED_VALUE_NAME = "column_value"
    # Column used to indicate the monitor config version used to refresh a row in the output table
    MONITOR_VERSION = "monitor_version"

    # Slice columns.
    SLICE_KEY_COLUMN = "slice_key"
    SLICE_VALUE_COLUMN = "slice_value"
    LOGGING_TABLE_COMMIT_VERSION = "logging_table_commit_version"


BASIC_PROFILE_TABLE_CONTEXT_COLUMNS_SCHEMA = T.StructType([
    T.StructField(
        name=ProfileTableConstants.WINDOW_COLUMN,
        dataType=T.StructType([
            T.StructField('start', T.TimestampType(), True),
            T.StructField('end', T.TimestampType(), True)
        ]),
        nullable=True),
    T.StructField(
        name=ProfileTableConstants.GRANULARITY_COLUMN, dataType=T.StringType(), nullable=True),
    T.StructField(
        name=ProfileTableConstants.LOG_TYPE_COLUMN, dataType=T.StringType(), nullable=True),
    T.StructField(
        name=ProfileTableConstants.SLICE_KEY_COLUMN, dataType=T.StringType(), nullable=True),
    T.StructField(
        name=ProfileTableConstants.SLICE_VALUE_COLUMN, dataType=T.StringType(), nullable=True),
    T.StructField(
        name=ProfileTableConstants.LOGGING_TABLE_COMMIT_VERSION,
        dataType=T.IntegerType(),
        nullable=True),
])

BASIC_DRIFT_TABLE_CONTEXT_COLUMNS_SCHEMA = T.StructType([
    T.StructField(
        name=ProfileTableConstants.WINDOW_COLUMN,
        dataType=T.StructType([
            T.StructField('start', T.TimestampType(), True),
            T.StructField('end', T.TimestampType(), True)
        ]),
        nullable=True),
    T.StructField(
        name=ProfileTableConstants.CMP_WINDOW_COLUMN,
        dataType=T.StructType([
            T.StructField('start', T.TimestampType(), True),
            T.StructField('end', T.TimestampType(), True)
        ]),
        nullable=True),
    T.StructField(
        name=ProfileTableConstants.GRANULARITY_COLUMN, dataType=T.StringType(), nullable=True),
    T.StructField(name=ProfileTableConstants.DRIFT_TYPE, dataType=T.StringType(), nullable=True),
    T.StructField(
        name=ProfileTableConstants.SLICE_KEY_COLUMN, dataType=T.StringType(), nullable=True),
    T.StructField(
        name=ProfileTableConstants.SLICE_VALUE_COLUMN, dataType=T.StringType(), nullable=True),
])


class RunnerMode(str, Enum):
    """Runner mode."""
    FULL = "FULL"
    INCREMENTAL = "INCREMENTAL"


class LogType(str, Enum):
    """The type of logged data."""
    INPUT = "INPUT"
    BASELINE = "BASELINE"


class DriftType(str, Enum):
    """The type of drift analysis."""
    CONSECUTIVE = "CONSECUTIVE"
    BASELINE = "BASELINE"


class DatabricksPermissionsEndpoint(str, Enum):
    # Details: https://docs.databricks.com/dev-tools/api/latest/permissions.html#operation/set-job-permissions
    JOBS = "jobs"
    # Details: https://docs.databricks.com/dev-tools/api/latest/permissions.html#operation/set-notebook-permissions
    NOTEBOOKS = "notebooks"
    # Details: https://docs.databricks.com/dev-tools/api/latest/permissions.html#operation/set-pipeline-permissions
    PIPELINES = "pipelines"


# Delimiter used by ConfusionMatrix metric to concatenate and parse prediction/label pairs
# Cannot be defined in aggregate_metric or metric_utils module due to cyclic dependency
CONFUSION_MATRIX_DELIMITER = ";"

# The granularity string for grouping by the timestamp that analysis begins
EXACT_GRANULARITY = "exact"

# Linter.IfChange
# Static granularities only exist for fixed increments, like 30 minutes or 1 year.
VALID_STATIC_GRANULARITIES = {"5 minutes", "30 minutes", "1 hour", "1 day", "1 month", "1 year"}

# Variable granularities can be defined for any integer of units like 3 weeks.
VALID_VARIABLE_GRANULARITIES = {"week"}

# Generated valid granularity string regex pattern.
VALID_PAT = "|".join((
    # Static pattern
    "|".join(f"({granularity}$)" for granularity in VALID_STATIC_GRANULARITIES),
    # Variable pattern: n unit(s), where 1<=n<=4
    # Note: this pattern will need to be updated if we support multiples of non-week window
    # duration.
    "|".join(rf"(?:^[1-4] {granularity}s?$)" for granularity in VALID_VARIABLE_GRANULARITIES)))
# Linter.ThenChange(data-monitoring/service/data-monitoring/src/DataMonitoringRpcValidationHook.scala)

VALID_ENTITY_FORMATS = (
    "^models:/[^/]+$",  # Model register uri.
)

MODEL_ENTITY = "models"

# Reserved column names used by profile table.
RESERVED_COLUMN_NAMES = [col.name for col in BASIC_PROFILE_TABLE_CONTEXT_COLUMNS_SCHEMA
                         ] + [ProfileTableConstants.TABLE_INPUT_NAME]
