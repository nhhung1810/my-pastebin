"""
This module provides the Databricks version of Context and a decorator to set it for API calls
"""
from __future__ import annotations

import functools
import logging
import time
from typing import Any, Mapping, Optional
import inspect

from pyspark.sql import SparkSession

from databricks.data_monitoring import table_utils, errors
from databricks.data_monitoring.context import Context
from databricks.data_monitoring.clients import (
    base_monitoring_service_client, databricks_monitoring_service_client, uc_client,
    databricks_uc_client, databricks_redash_client, redash_client)

_UNITY_CATALOG_ENABLED = "spark.databricks.unityCatalog.enabled"

_logger = logging.getLogger(__name__)


class DatabricksContext(Context):
    """
    Data Monitoring context for Databricks execution.

    NOTE: This class is not covered by unit tests and is meant to be tested through
    DUST suites that run this code on an actual Databricks cluster.
    """

    @classmethod
    def _get_dbutils(cls):
        """
        Returns an instance of dbutils.
        """
        try:
            from databricks.sdk.runtime import dbutils
            return dbutils
        except ImportError:
            import IPython
            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils

    def __init__(self, spark=None):
        if spark:
            self._spark = spark
        else:
            self._spark = SparkSession \
                .builder \
                .appName("databricks.data_monitoring") \
                .getOrCreate()

        self._dbutils = self._get_dbutils()
        self._notebook_context = self._dbutils.entry_point.getDbutils().notebook()\
            .getContext()
        api_url = self._notebook_context.apiUrl().get()
        api_token = self._notebook_context.apiToken().get()
        # TODO: Deprecate the metadata store client once we've fully switched over to the service
        self._service_client = databricks_monitoring_service_client.DatabricksMonitoringServiceClient(
            workspace_url=api_url,
            api_token=api_token,
        )

        self._uc_client = databricks_uc_client.DatabricksUcClient(
            workspace_url=api_url, api_token=api_token)

        self._redash_client = databricks_redash_client.DatabricksRedashClient(
            workspace_url=api_url,
            api_token=api_token,
        )

    def get_spark(self) -> SparkSession:
        return self._spark

    def get_service_client(self) -> base_monitoring_service_client.MonitoringServiceClient:
        return self._service_client

    def get_uc_client(self) -> uc_client.UcClient:
        return self._uc_client

    def get_redash_client(self) -> redash_client.RedashClient:
        return self._redash_client

    def get_user_name(self) -> str:
        # This has been verified to work on DBR 12.0 and above, however it may not work
        # for older DBRs because the function `userName()` is added after 2021/08
        # See common/chauffeur/command/src/CommandContext.scala
        return self._notebook_context.userName().get()

    def get_workspace_url(self) -> Optional[str]:
        browser_host_name_obj = self._notebook_context.browserHostName()
        # Headless dust suite does not have browserHostName.
        if browser_host_name_obj.isEmpty():
            return None
        browser_hostname = browser_host_name_obj.get()
        workspace_id = self._notebook_context.workspaceId().get()
        return f"https://{browser_hostname}/?o={workspace_id}"

    def uc_enabled(self) -> bool:
        return self._spark.conf.get(_UNITY_CATALOG_ENABLED) == "true"

    def display_html(self, html) -> None:
        # pylint: disable=protected-access
        self._dbutils.notebook.displayHTML(html)

    def clear_context(self) -> None:
        pass

    def get_job_id(self) -> Optional[str]:
        try:
            job_id = self._notebook_context.jobId().get()
            return job_id
        except:
            return None

    def get_run_id(self) -> Optional[str]:
        try:
            run_id = self._notebook_context.parentRunId().get()
            return run_id
        except:
            return None


# Arguments that should be converted to fully qualified table names
# when passed into data monitoring APIs
_OPTIONAL_TABLE_ARGS_TO_QUALIFY = [
    "baseline_table_name",
]

# Arguments that should be converted to fully qualified schema names
# when passed into data monitoring APIs
_OPTIONAL_SCHEMA_ARGS_TO_QUALIFY = [
    "output_schema_name",
]


def preprocess_securables(params: Mapping[str, Any]) -> None:
    """
    Helper to apply preprocessing to securables (i.e., extracting fully qualified name) in a
    dictionary of parameters.

    :param params: Mapping of parameter names to parameters to consider for preprocessing
    """
    input_table_name = _maybe_preprocess_table_param(param_name="table_name", params=params)
    if input_table_name is None:
        # We rely on this to be non-empty to autocomplete the catalog / schema of other user provided params
        return

    for param_name in params:
        if param_name in _OPTIONAL_TABLE_ARGS_TO_QUALIFY:
            _maybe_preprocess_table_param(param_name=param_name, params=params)
        elif param_name in _OPTIONAL_SCHEMA_ARGS_TO_QUALIFY:
            # Schema args may have None values by default, but we can autocomplete to the input table schema
            val = params[param_name]
            schema_name = table_utils.SchemaName(val, input_table_name.schema_name)
            schema_name.warn_if_autocompleted(_logger, param_name)
            params[param_name] = schema_name.fully_qualified_name


def _maybe_preprocess_table_param(param_name: str,
                                  params: Mapping[str, Any]) -> Optional[table_utils.TableName]:
    """
    Helper to apply preprocessing to a table name parameter (i.e., extracting fully qualified name)
    :param param_name: The table name parameter to extract
    :param params: All user specified parameters
    """
    table_name = None
    if param_name in params:
        val = params[param_name]
        if val is None or not isinstance(val, str):
            # ignore non-existent params or non-string params (securables must be strings)
            return None
        table_name = table_utils.TableName(val)
        table_name.warn_if_autocompleted(_logger)
        params[param_name] = table_name.fully_qualified_name
    return table_name


def data_monitoring_api(func):
    """
    Decorator for wrapping all Data Monitoring APIs with setup and closure logic.

    The wrapper will setup an active DatabricksContext if there isn't one already,
    and will also instrument the API call to add usage logging by timing it and
    recording the parameters and errors (if any).

    :param func: Data Monitoring function to wrap
    :return: return value of func
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # TODO (ML-27303): Change wrapper logic to use inspect rather than kwargs
        if not Context.active:
            Context.current = DatabricksContext()

        error = None
        result = None
        start_time = time.perf_counter()

        parameters = inspect.signature(func).parameters
        # Get all the parameters with default values from the method signature.
        # If a parameter does not have default value, it will not be included in the `full_kwargs`.
        full_kwargs = {
            param_name: parameters[param_name].default
            for param_name in parameters
            if parameters[param_name].default != inspect.Parameter.empty
        }
        # Merge the parameters default values with the values passed in by the user.
        full_kwargs.update(kwargs)
        # Preprocess kwargs to convert table names and schema names to fully qualified names.
        # By default, table names (baseline + primary) and output schema names may be autocompleted.
        # The output_schema, if not fully specified, will fallback to the catalog and schema of the monitored table.
        preprocess_securables(full_kwargs)

        try:
            if not Context.current.uc_enabled():
                raise errors.DataMonitoringError(
                    error_code=errors.DataMonitoringErrorCode.RUNTIME_NOT_SUPPORTED)
            result = func(*args, **full_kwargs)
        except Exception as e:  # pylint: disable=broad-except
            error = e
        finally:
            # perf_counter returns fractional seconds, so we convert to whole milliseconds
            elapsed_time = int(round((time.perf_counter() - start_time) * 1000))

            # Raise the original error if there was one, otherwise return
            if error is not None:
                raise error
            else:
                return result  # pylint: disable=lost-exception

    return wrapper
