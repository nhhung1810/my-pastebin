"""
Conversion metadata <-> proto-compatible JSON

The module defines helper methods to obtain and set the values of optional proto fields:
- set_optional_field
- set_repeated_field
- get_required_field
- get_required_list

Serialization code should use these methods instead of getting/setting directly dict fields
so that we can maintain consistency between Py-friendly structs and JSON-to-proto-serialization semantics.
"""
import abc
import json
from typing import Any, Collection, Mapping, Optional, Union, List, Iterable, TypeVar, Generic, \
    Dict, Tuple

import pydantic.dataclasses
import pyspark.sql.types as T

from databricks.data_monitoring import metadata, errors, const, metrics, analysis

# We will use a dict to represent the proto.
# Serialization can happen trivially through `json.dumps()`, and similarly
# for deserialization with `json.loads()`.
JsonProto = Dict[str, Any]


def set_optional_field(json_proto: JsonProto, field: str, value: Optional[Any]) -> None:
    """
    Sets an optional field to the input value if the latter is not None.
    :param json_proto: The json proto to be updated.
    :param field: The name of the field.
    :param value: An optional value.
    """
    if value is None:
        return

    json_proto[field] = value


def set_repeated_field(json_proto: JsonProto, field: str, value: Optional[Collection]) -> None:
    """
    Sets a repeated field to the input value if the latter is not empty.
    :param json_proto: The json proto to be updated.
    :param field: The name of the field.
    :param value: An optional collection
    """
    if value is not None and len(value) > 0:
        json_proto[field] = value


def get_required_field(json_dict: Mapping[str, Any], field: str) -> Any:
    """
    Gets the value of a required field. Throws an error if the field is not set.
    :param json_dict: The json proto that is assumed to hold the field.
    :param field: The name of the field.
    :return: The value of the field.
    """
    if field not in json_dict:
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
            message=f"Serialization error: could not find field '{field}' in {json.dumps(json_dict)}"
        )
    return json_dict.get(field)


def get_required_list(json_dict: Mapping[str, Any], field: str) -> List:
    """
    Gets the value of a required repeated field. Throws an error if the field is not set.
    :param json_dict: The json proto that is assumed to hold the field.
    :param field: The name of the field.
    :return: The value of the field.
    """
    if field not in json_dict:
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
            message=f"Serialization error: could not find field '{field}' in {json.dumps(json_dict)}"
        )
    return list(json_dict.get(field))


def get_optional_list(json_dict: Mapping[str, Any], field: str) -> List:
    """
    Similar to get_required_list above but returns an empty list if the field is not set.
    """
    return list() if field not in json_dict else list(json_dict.get(field))


def get_optional_field(json_dict: Mapping[str, Any], field: str) -> Optional[Any]:
    """
    Gets the value of an optional field.

    :param json_dict: The json proto that is assumed to hold the field.
    :param field: The name of the field.
    :return: The value of the field or None if the field is not set.
    """
    return None if field not in json_dict else json_dict.get(field)


Left = TypeVar("Left")
Right = TypeVar("Right")


class BijectiveMapping(Generic[Left, Right]):
    """
    Represents a bijective mapping.

    Example usage:

    mapping = BijectiveMapping[str, int](mapping={"a":1, "b":2},
                                         left_to_right_direction="str_to_int",
                                         right_to_left_direction="int_to_str")

    assert 2 == mapping.get(direction="str_to_int", key = "a")
    assert "b" == mapping.get(direction="int_to_str", key = 2)

    """

    def __init__(self, mapping: Mapping[Left, Right], left_to_right_direction: str,
                 right_to_left_direction: str):
        # Validate that we can infer a bijective mapping
        assert len(mapping.values()) == len(set(mapping.values()))

        self._left_to_right_direction = left_to_right_direction
        self._right_to_left_direction = right_to_left_direction

        self._left_to_right_mapping = mapping
        self._right_to_left_mapping = {v: k for k, v in self._left_to_right_mapping.items()}

    def get(self, direction: str, key: Union[Left, Right]) -> Union[Right, Left]:
        """
        Maps a key to a value, according to the specified direction.
        Raises an error if the key is not in the map.
        :param direction: One of the direction strings provided in the constructor.
        :param key: the key to lookup in the bijective mapping
        :return: the mapped value (in the given direction).
        """
        if direction == self._left_to_right_direction:
            return self._left_to_right_mapping.get(key)
        elif direction == self._right_to_left_direction:
            return self._right_to_left_mapping.get(key)
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
                message=f"Invalid bijective mapping direction: {direction}")


PyEnum = TypeVar("PyEnum")


class EnumMapper(Generic[PyEnum], abc.ABC):
    """
    Base class to map enums from their Python values to their proto representations as strings, and vice versa.
    """

    @classmethod
    @abc.abstractmethod
    def _get_mapping(cls) -> BijectiveMapping[PyEnum, str]:
        """
        :return: a bijective mapping from enum values to proto enums. Must have "to_proto" and "from_proto" directions.
        """
        pass

    @classmethod
    @abc.abstractmethod
    def _get_enum_name(cls) -> str:
        """
        :return: A humna-readable description of the enum. Used in error messages.
        """
        pass

    @classmethod
    @abc.abstractmethod
    def _get_enum_value_for_none(cls) -> str:
        """
        :return: The proto enum value corresponding to None in Python.
        """
        pass

    @classmethod
    def to_json(cls, value: Optional[PyEnum]) -> str:
        """Converts to proto representation"""
        if value is None:
            return cls._get_enum_value_for_none()

        result = cls._get_mapping().get(key=value, direction="to_proto")
        if result is None:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
                message=f"Unable to map python value {cls._get_enum_name()} '{value}'")
        return result

    @classmethod
    def from_json(cls, value: str) -> Optional[PyEnum]:
        """Recovers from proto representation"""
        if value == cls._get_enum_value_for_none():
            return None

        result = cls._get_mapping().get(key=value, direction="from_proto")
        if result is None:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
                message=f"Unable to map {cls._get_enum_name()} '{value}'")
        return result


class MetricTypeMapper(EnumMapper[const.MetricType]):
    """
    Maps a metric type from/to proto representation
    """

    _MAPPING = BijectiveMapping[str, const.MetricType](
        mapping={
            "CUSTOM_METRIC_TYPE_AGGREGATE": const.MetricType.AGGREGATE,
            "CUSTOM_METRIC_TYPE_DRIFT": const.MetricType.DRIFT,
            "CUSTOM_METRIC_TYPE_DERIVED": const.MetricType.DERIVED
        },
        left_to_right_direction="from_proto",
        right_to_left_direction="to_proto")

    @classmethod
    def _get_mapping(cls) -> BijectiveMapping[str, const.MetricType]:
        return cls._MAPPING

    @classmethod
    def _get_enum_value_for_none(cls) -> str:
        return "CUSTOM_METRIC_TYPE_UNSPECIFIED"

    @classmethod
    def _get_enum_name(cls) -> str:
        return "custom metric type"


class RefreshStateMapper(EnumMapper[metadata.RefreshState]):
    """
    Maps a refresh state from proto representation
    """

    _MAPPING = BijectiveMapping[str, metadata.RefreshState](
        mapping={
            "PENDING": metadata.RefreshState.PENDING,
            "RUNNING": metadata.RefreshState.RUNNING,
            "SUCCESS": metadata.RefreshState.SUCCESS,
            "FAILED": metadata.RefreshState.FAILED,
            "CANCELED": metadata.RefreshState.CANCELED,
        },
        left_to_right_direction="from_proto",
        right_to_left_direction="to_proto")

    @classmethod
    def _get_mapping(cls) -> BijectiveMapping[str, metadata.RefreshState]:
        return cls._MAPPING

    @classmethod
    def _get_enum_value_for_none(cls) -> str:
        return "UNKNOWN"

    @classmethod
    def _get_enum_name(cls) -> str:
        return "refresh state"


class MetricMapper:
    """
    Maps a metric from/to proto representation
    """

    @classmethod
    def to_json(cls, metric: metrics.Metric) -> JsonProto:
        """Converts metric to its proto representation"""
        result = dict(
            type=MetricTypeMapper.to_json(const.MetricType(metric.type)),
            name=metric.name,
            input_columns=metric.input_columns,
            output_data_type=T.StructField("output", metric.output_data_type).json(),
            definition=metric.definition)
        return result

    @classmethod
    def from_json(cls, proto_metric: JsonProto) -> metrics.Metric:
        """Constructs metric from its proto representation"""
        output_field = T.StructField.fromJson(
            json.loads(get_required_field(proto_metric, "output_data_type")))

        return metrics.Metric(
            type=MetricTypeMapper.from_json(get_required_field(proto_metric, "type")),
            name=get_required_field(proto_metric, "name"),
            definition=get_required_field(proto_metric, "definition"),
            output_data_type=output_field.dataType,
            # Include deprecated target_columns field for backwards compatibility
            input_columns=get_required_list(proto_metric, "input_columns") + get_optional_list(
                proto_metric, "target_columns"))

    @classmethod
    def from_json_list(
            cls, proto_metrics: Optional[Iterable[JsonProto]]) -> Optional[List[metrics.Metric]]:
        if proto_metrics is None:
            return None
        return [cls.from_json(metric) for metric in proto_metrics]


class MonitorStatusMapper(EnumMapper[metadata.MonitorStatus]):
    """Converts monitor status to/from proto representation"""

    # Mapping of enum values
    _MAPPING = BijectiveMapping[metadata.MonitorStatus, str](
        mapping={
            metadata.MonitorStatus.ACTIVE: "MONITOR_STATUS_ACTIVE",
            metadata.MonitorStatus.PENDING: "MONITOR_STATUS_PENDING",
            metadata.MonitorStatus.DELETE_PENDING: "MONITOR_STATUS_DELETE_PENDING",
            metadata.MonitorStatus.ERROR: "MONITOR_STATUS_ERROR",
            metadata.MonitorStatus.FAILED: "MONITOR_STATUS_FAILED",
        },
        left_to_right_direction="to_proto",
        right_to_left_direction="from_proto")

    @classmethod
    def _get_mapping(cls) -> BijectiveMapping[metadata.MonitorStatus, str]:
        return cls._MAPPING

    @classmethod
    def _get_enum_name(cls) -> str:
        return "monitor status"

    @classmethod
    def _get_enum_value_for_none(cls) -> str:
        return "MONITOR_STATUS_UNSPECIFIED"


class ProblemTypeMapper(EnumMapper[const.ProblemType]):
    """Maps ProblemType enum to proto"""

    # Mapping between enum values
    _MAPPING = BijectiveMapping[const.ProblemType, str](
        mapping={
            const.ProblemType.CLASSIFICATION: "PROBLEM_TYPE_CLASSIFICATION",
            const.ProblemType.REGRESSION: "PROBLEM_TYPE_REGRESSION"
        },
        left_to_right_direction="to_proto",
        right_to_left_direction="from_proto")

    @classmethod
    def _get_mapping(cls) -> BijectiveMapping[const.ProblemType, str]:
        return cls._MAPPING

    @classmethod
    def _get_enum_name(cls) -> str:
        return "problem type"

    @classmethod
    def _get_enum_value_for_none(cls) -> str:
        return "PROBLEM_TYPE_UNSPECIFIED"


class SnapshotMapper:
    """ Converts Snapshot instances to/from proto"""

    @classmethod
    def to_json(cls, _: analysis.Snapshot) -> JsonProto:
        return {}

    @classmethod
    def from_json(cls, _: JsonProto) -> analysis.Snapshot:
        return analysis.Snapshot()


class TimeSeriesMapper:
    """ Converts TimeSeries instances to/from proto"""

    @classmethod
    def to_json(cls, time_series: analysis.TimeSeries) -> JsonProto:
        result = {}
        set_optional_field(result, "timestamp_col", time_series.timestamp_col)
        set_repeated_field(result, "granularities", time_series.granularities)
        return result

    @classmethod
    def from_json(cls, proto: JsonProto) -> analysis.TimeSeries:
        return analysis.TimeSeries(
            timestamp_col=get_required_field(proto, "timestamp_col"),
            granularities=get_required_list(proto, "granularities"))


class InferenceLogMapper:
    """Converts InferenceLog instances to/from proto"""

    @classmethod
    def to_json(cls, inference_log: analysis.InferenceLog) -> JsonProto:
        """
        Converts the input InferenceLog instance to a proto representation

        :param inference_log: The configuration for the inference-log
        :return: Proto representation
        """
        result = {}
        set_optional_field(result, "problem_type",
                           ProblemTypeMapper.to_json(inference_log.problem_type))
        set_optional_field(result, "timestamp_col", inference_log.timestamp_col)
        set_optional_field(result, "prediction_col", inference_log.prediction_col)
        set_optional_field(result, "label_col", inference_log.label_col)
        set_optional_field(result, "model_id_col", inference_log.model_id_col)
        set_repeated_field(result, "granularities", inference_log.granularities)
        set_optional_field(result, "prediction_proba_col", inference_log.prediction_proba_col)

        return result

    @classmethod
    def from_json(cls, config: JsonProto) -> analysis.InferenceLog:
        """
        Returns an InferenceLog analysis type from the specified proto

        :param config:
        :return: An instance of InferenceLog constructed from the proto's parameters
        """
        result = analysis.InferenceLog(
            timestamp_col=get_required_field(config, "timestamp_col"),
            granularities=get_required_list(config, "granularities"),
            problem_type=ProblemTypeMapper.from_json(get_required_field(config, "problem_type")),
            prediction_col=get_required_field(config, "prediction_col"),
            label_col=get_optional_field(config, "label_col"),
            model_id_col=(
                # After renaming model_version_col -> model_id_col, we still need to be able to
                # parse old monitors whose InferenceLog uses model_version_col
                # until we sunset those monitors.
                get_optional_field(config, "model_id_col") or
                get_optional_field(config, "model_version_col")),
            prediction_proba_col=get_optional_field(config, "prediction_proba_col"),
        )
        return result


AnalysisType = Union[analysis.InferenceLog, analysis.TimeSeries, analysis.Snapshot]


class AnalysisTypeMapper:
    """Maps an metadata instance (e.g., InferenceLog) to its proto representation and back"""

    @pydantic.dataclasses.dataclass(config=const.PydanticConfig)
    class AnalysisTypeSerializationInfo:
        # Analysis class, e.g., InferenceLog, TimeSeries, ...
        analysis_class: Any
        # Field name of the analysis_config oneof
        field_name: str
        # Mapper class. Assumed to have a `to_proto` method that accepts an instance of `analysis_class` and
        # returns a proto that be plugged in `field_name` of MonitorConfig, and a `from_proto` method with the inverse
        # semantics.
        mapper: Any

    @classmethod
    def _get_mapping(cls) -> Collection["AnalysisTypeSerializationInfo"]:
        return [
            cls.AnalysisTypeSerializationInfo(
                analysis_class=analysis.InferenceLog,
                field_name="inference_log",
                mapper=InferenceLogMapper),
            cls.AnalysisTypeSerializationInfo(
                analysis_class=analysis.TimeSeries,
                field_name="time_series",
                mapper=TimeSeriesMapper),
            cls.AnalysisTypeSerializationInfo(
                analysis_class=analysis.Snapshot, field_name="snapshot", mapper=SnapshotMapper),
        ]

    @classmethod
    def to_json(cls, analysis_obj: AnalysisType) -> Tuple[str, JsonProto]:
        """
        Converts the input analysis object to a json proto representation
        :param analysis_obj:
        :return: A tuple (name, proto) that represents the input analysis object and can be inlined as a field into a
            MonitorConfiguration json proto.
        """
        for known_type in cls._get_mapping():
            if isinstance(analysis_obj, known_type.analysis_class):
                proto = known_type.mapper.to_json(analysis_obj)
                return known_type.field_name, proto
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
            message=f"Cannot identify analysis type '{type(analysis_obj)}'")

    @classmethod
    def from_json(cls, config: JsonProto) -> AnalysisType:
        """
        Decodes the analysis type from an input proto that represents a MonitorConfig. Throws an error if the input
        proto does not contain a known analysis type.
        :param config: A json proto of a MonitorConfig
        :return: The inferred analysis type
        """
        for known_type in cls._get_mapping():
            if known_type.field_name in config:
                return known_type.mapper.from_json(
                    get_required_field(config, known_type.field_name))
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
            message=f"Cannot identify analysis type from config {json.dumps(config)}")


class MonitorCronScheduleMapper:
    """Converts MonitorCronSchedule instances to/from proto"""

    @classmethod
    def to_json(cls, schedule: Optional[metadata.MonitorCronSchedule]) -> JsonProto:
        """
        Converts the input MonitorCronSchedule instance to a proto representation

        :param schedule: The monitor's cron refresh schedule
        :return: Proto representation
        """
        if schedule is None:
            return None

        result = {}
        set_optional_field(result, "quartz_cron_expression", schedule.quartz_cron_expression)
        set_optional_field(result, "timezone_id", schedule.timezone_id)

        return result

    @classmethod
    def from_json(cls, schedule_proto: JsonProto) -> Optional[metadata.MonitorCronSchedule]:
        """
        Returns a MonitorCronSchedule from the specified proto

        :param schedule_proto: JSON representation of schedule proto
        :return: An instance of MonitorCronSchedule constructed from the proto
        """
        if schedule_proto is None:
            return None
        return metadata.MonitorCronSchedule(
            quartz_cron_expression=get_optional_field(schedule_proto, "quartz_cron_expression"),
            timezone_id=get_optional_field(schedule_proto, "timezone_id"),
        )


def json_to_refresh_info(proto: JsonProto) -> metadata.RefreshInfo:
    """
    Deserializes a proto (in JSON format) into a RefreshInfo object.
    This method should be used to transform monitor refresh information returned by our service.

    :param proto: Proto in JSON format to deserialize
    :return: Fully populated RefreshInfo object
    """
    # Note we need to cast `refresh_id` to str because it's defined as int64 in proto definitions
    return metadata.RefreshInfo(
        refresh_id=str(get_required_field(proto, "refresh_id")),
        state=RefreshStateMapper.from_json(get_required_field(proto, "state")),
        start_time_ms=get_required_field(proto, "start_time_ms"),
        end_time_ms=get_optional_field(proto, "end_time_ms"),
        message=get_optional_field(proto, "message"),
    )


def monitor_info_to_json(info: metadata.MonitorInfo) -> JsonProto:
    """
    Serializes a MonitorInfo object into a proto (in JSON format).
    This method should be used to transform monitor information before sending it to our service.

    :param info: MonitorInfo to serialize
    :return: Populated proto in JSON
    """
    result = {}

    if info.profile_type is not None:
        field_name, analysis_proto = AnalysisTypeMapper.to_json(info.profile_type)
        result[field_name] = analysis_proto

    custom_metrics = []
    for metric in info.custom_metrics if info.custom_metrics is not None else []:
        custom_metrics.append(MetricMapper.to_json(metric))
    set_repeated_field(result, "custom_metrics", custom_metrics)
    set_optional_field(result, "slicing_exprs", info.slicing_exprs)
    set_optional_field(result, "baseline_table_name", info.baseline_table_name)
    set_optional_field(result, "output_schema_name", info.output_schema_name)
    set_optional_field(result, "schedule", MonitorCronScheduleMapper.to_json(info.schedule))
    set_optional_field(result, "assets_dir", info.assets_dir)

    # Note that these fields should pretty much never be changed/set from the Python client,
    # but we include them here for completeness.
    set_optional_field(result, "table_name", info.table_name)
    set_optional_field(result, "status", MonitorStatusMapper.to_json(info.status))
    set_optional_field(result, "latest_monitor_failure_msg", info.latest_monitor_failure_msg)
    set_optional_field(result, "profile_metrics_table_name", info.profile_metrics_table_name)
    set_optional_field(result, "drift_metrics_table_name", info.drift_metrics_table_name)
    set_optional_field(result, "dashboard_id", info.dashboard_id)
    set_optional_field(result, "monitor_version", info.monitor_version)

    return result


def json_to_monitor_info(proto: JsonProto) -> metadata.MonitorInfo:
    """
    Deserializes a proto (in JSON format) into a MonitorInfo object.
    This method should be used to transform monitor information returned by our service.

    :param proto: Proto in JSON format to deserialize
    :return: Fully populated MonitorInfo object
    """
    return metadata.MonitorInfo(
        profile_type=AnalysisTypeMapper.from_json(proto),
        slicing_exprs=get_optional_field(proto, "slicing_exprs"),
        custom_metrics=MetricMapper.from_json_list(get_optional_field(proto, "custom_metrics")),
        baseline_table_name=get_optional_field(proto, "baseline_table_name"),
        output_schema_name=get_optional_field(proto, "output_schema_name"),
        schedule=MonitorCronScheduleMapper.from_json(get_optional_field(proto, "schedule")),
        table_name=get_required_field(proto, "table_name"),
        status=MonitorStatusMapper.from_json(get_required_field(proto, "status")),
        latest_monitor_failure_msg=get_optional_field(proto, "latest_monitor_failure_msg"),
        profile_metrics_table_name=get_required_field(proto, "profile_metrics_table_name"),
        drift_metrics_table_name=get_required_field(proto, "drift_metrics_table_name"),
        dashboard_id=get_optional_field(proto, "dashboard_id"),
        assets_dir=get_optional_field(proto, "assets_dir"),
        monitor_version=get_required_field(proto, "monitor_version"),
    )


def to_create_monitor_json(info: metadata.CreateMonitorInfo,
                           skip_builtin_dashboard: bool,
                           warehouse_id: Optional[str] = None) -> JsonProto:
    """
    Serializes a CreateMonitorInfo object, along with customization options, into a create-monitor request proto
    (in JSON format). This method should be used to transform monitor creation information before sending it to our
    service.

    :param info: CreateMonitorInfo to serialize
    :param skip_builtin_dashboard: Whether to skip creating a built-in dashboard
    :param warehouse_id: Warehouse ID for the dashboard to attach to
    :return: Populated proto in JSON
    """
    result = {}

    field_name, analysis_proto = AnalysisTypeMapper.to_json(info.profile_type)
    result[field_name] = analysis_proto

    custom_metrics = []
    for metric in info.custom_metrics if info.custom_metrics is not None else []:
        custom_metrics.append(MetricMapper.to_json(metric))
    set_repeated_field(result, "custom_metrics", custom_metrics)
    set_optional_field(result, "slicing_exprs", info.slicing_exprs)
    set_optional_field(result, "baseline_table_name", info.baseline_table_name)
    set_optional_field(result, "output_schema_name", info.output_schema_name)
    set_optional_field(result, "schedule", MonitorCronScheduleMapper.to_json(info.schedule))
    set_optional_field(result, "assets_dir", info.assets_dir)
    set_optional_field(result, "skip_builtin_dashboard", skip_builtin_dashboard)
    set_optional_field(result, "warehouse_id", warehouse_id)
    return result


class ProfilingStateMapper(EnumMapper[metadata.RefreshState]):
    """Maps a profiling job run state from/to proto representation"""

    _MAPPING = BijectiveMapping[str, metadata.ProfilingState](
        mapping={
            "PROFILING_STATE_SUCCESS": metadata.ProfilingState.SUCCESS,
            "PROFILING_STATE_FAILED": metadata.ProfilingState.FAILED
        },
        left_to_right_direction="from_proto",
        right_to_left_direction="to_proto")

    @classmethod
    def _get_mapping(cls) -> BijectiveMapping[str, metadata.ProfilingState]:
        return cls._MAPPING

    @classmethod
    def _get_enum_value_for_none(cls) -> str:
        return "PROFILING_STATE_UNSPECIFIED"

    @classmethod
    def _get_enum_name(cls) -> str:
        return "profiling state"


class RunnerTypeMapper(EnumMapper[metadata.RunnerType]):
    """Maps a profiling runner type from/to proto representation"""

    _MAPPING = BijectiveMapping[str, metadata.RunnerType](
        mapping={
            "RUNNER_TYPE_UNASSIGNED": metadata.RunnerType.UNASSIGNED,
            "RUNNER_TYPE_BASE": metadata.RunnerType.BASE,
            "RUNNER_TYPE_FULL": metadata.RunnerType.FULL,
            "RUNNER_TYPE_INCREMENTAL": metadata.RunnerType.INCREMENTAL
        },
        left_to_right_direction="from_proto",
        right_to_left_direction="to_proto")

    @classmethod
    def _get_mapping(cls) -> BijectiveMapping[str, metadata.RunnerType]:
        return cls._MAPPING

    @classmethod
    def _get_enum_value_for_none(cls) -> str:
        return "RUNNER_TYPE_UNSPECIFIED"

    @classmethod
    def _get_enum_name(cls) -> str:
        return "runner type"


class PreRunMetricsMapper:
    """Converts PreRunMetric instances to proto"""

    @classmethod
    def to_json(cls, metrics: metadata.PreRunMetrics) -> JsonProto:
        """
        Converts the pre run stage profiling metrics from/to a proto representation
        """
        result = {}
        set_optional_field(result, "job_id", metrics.job_id)
        set_optional_field(result, "run_id", metrics.run_id)
        set_optional_field(result, "table_size", metrics.table_size)

        return result

    @classmethod
    def from_json(cls, proto: JsonProto) -> metadata.PreRunMetrics:
        return metadata.PreRunMetrics(
            job_id=get_optional_field(proto, "job_id"),
            run_id=get_optional_field(proto, "run_id"),
            table_size=get_optional_field(proto, "table_size"),
        )


class PostRunMetricsMapper:
    """Converts the post run stage profiling metrics from/to a proto representation"""

    @classmethod
    def to_json(cls, metrics: metadata.PostRunMetrics) -> JsonProto:
        """
        Converts the post run stage profiling metrics to a proto representation
        """
        result = {}
        set_optional_field(result, "job_id", metrics.job_id)
        set_optional_field(result, "run_id", metrics.run_id)
        set_optional_field(result, "state", ProfilingStateMapper.to_json(metrics.state))
        set_optional_field(result, "error_code", metrics.error_code)
        set_optional_field(result, "error_msg", metrics.error_msg)
        set_optional_field(result, "error_trace", metrics.error_trace)
        set_optional_field(result, "runner_type", RunnerTypeMapper.to_json(metrics.runner_type))
        return result

    @classmethod
    def from_json(cls, proto: JsonProto) -> metadata.PostRunMetrics:
        return metadata.PostRunMetrics(
            job_id=get_optional_field(proto, "job_id"),
            run_id=get_optional_field(proto, "run_id"),
            state=ProfilingStateMapper.from_json(get_optional_field(proto, "state")),
            error_code=get_optional_field(proto, "error_code"),
            error_msg=get_optional_field(proto, "error_msg"),
            error_trace=get_optional_field(proto, "error_trace"),
            runner_type=RunnerTypeMapper.from_json(get_optional_field(proto, "runner_type")),
        )


ProfilingMetricsType = Union[metadata.PreRunMetrics, metadata.PostRunMetrics]


class ProfilingMetricsMapper:
    """Maps observability of profiling job run from/to proto"""

    @pydantic.dataclasses.dataclass
    class ProfilingMetricsSerializationInfo:
        """Contains information for serializing an `oneof` profiling metrics."""
        # Metrics type, e.g., PostRun, PreRun, ...
        metrics_type: Any
        # Field name of the metrics_type oneof
        field_name: str
        # Mapper class. Assumed to have a `to_proto` method that accepts an instance of `metrics_type` class and
        # returns a proto that be plugged in `field_name` of ProfilingMetrics
        mapper: Any

    @classmethod
    def _get_mapping(cls) -> Collection["ProfilingMetricsSerializationInfo"]:
        return [
            cls.ProfilingMetricsSerializationInfo(
                metrics_type=metadata.PreRunMetrics,
                field_name="pre_run_metrics",
                mapper=PreRunMetricsMapper),
            cls.ProfilingMetricsSerializationInfo(
                metrics_type=metadata.PostRunMetrics,
                field_name="post_run_metrics",
                mapper=PostRunMetricsMapper),
        ]

    @classmethod
    def to_json(cls, metrics_obj: ProfilingMetricsType) -> JsonProto:
        """
        Converts the profiling metrics to a json proto representation

        :param metrics_obj: Profiling metrics to serialize
        :return: Populated proto in JSON
        """
        for known_type in cls._get_mapping():
            if isinstance(metrics_obj, known_type.metrics_type):
                proto = known_type.mapper.to_json(metrics_obj)
                return {known_type.field_name: proto}
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
            message=f"Cannot identify metrics type '{type(metrics_obj)}'")

    @classmethod
    def from_json(cls, metrics: JsonProto) -> ProfilingMetricsType:
        """
        Converts the profiling metrics from json proto to ProfilingMetricsType representation
        :param metrics: A json proto of a ProfilingMetrics
        :return: The inferred profiling metrics type
        """
        for known_type in cls._get_mapping():
            if known_type.field_name in metrics:
                return known_type.mapper.from_json(
                    get_required_field(metrics, known_type.field_name))
        raise errors.DataMonitoringError(
            error_code=errors.DataMonitoringErrorCode.INTERNAL_ERROR,
            message=f"Cannot identify metrics type  {json.dumps(metrics)}")


class ProfilingConfsMapper:
    """
    Converts ProfilingConfs instances from proto
    (we don't need the reverse because we don't send profiling confs back to the service).
    """

    @classmethod
    def from_json(cls, proto: JsonProto) -> metadata.ProfilingConfs:
        """
        Converts the profiling confs from a proto representation to a ProfilingConfs instance.
        :param proto: Proto dictionary to deserialize.
        :return: Hydrated ProfilingConfs instance.
        """
        if proto is None:
            return metadata.ProfilingConfs()

        return metadata.ProfilingConfs(
            drift_metrics_filter_threshold_days=get_optional_field(
                proto, "drift_metrics_filter_threshold_days"),
            profiling_filter_timestamp=get_optional_field(proto, "profiling_filter_timestamp"),
        )
