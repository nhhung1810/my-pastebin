from typing import Mapping

from databricks.data_monitoring import errors, const, table_utils
from databricks.data_monitoring.clients import uc_client, base_http_client


class DatabricksUcClient(base_http_client.DatabricksAPIClient, uc_client.UcClient):
    """
    An implementation of UcClient that works with the Databricks UC service.
    """

    def __init__(self, workspace_url: str, api_token: str):
        super().__init__(
            workspace_url=workspace_url,
            api_token=api_token,
            version="2.1",
            endpoint="unity-catalog")

    # Jinja template of path for the table endpoint
    _TABLE_PATH_TEMPLATE = "/tables/{{ full_table_name_arg }}"

    def _get_table_info(self, name: str) -> Mapping:
        """
        Returns the JSON representation of a TableInfo from the UC service. Raises
        DataMonitoringErrorCode.TABLE_NOT_FOUND if the table does not exist, or a DATA_MONITORING_SERVICE_ERROR
        if any other error occurs.

        :param name: The (partially or fully qualified) name of the table
        :return: A dict representing the JSON TableInfo
        """

        table_name = table_utils.TableName(name)

        method_path = self.get_method_path(
            method_template=self._TABLE_PATH_TEMPLATE,
            method_path_params=dict(full_table_name_arg=table_name.fully_qualified_name))

        with self.get_request_session() as s:
            resp = s.get(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code == 200:
            return resp.json()
        elif resp.status_code == 404:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.TABLE_NOT_FOUND,
                table_name=table_name.fully_qualified_delimited_name)
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def get_table_type(self, table_name: str) -> const.TableType:
        table_info = self._get_table_info(table_name)
        table_type = table_info["table_type"]
        source_format = table_info.get("data_source_format", "UNKNOWN_DATA_SOURCE_FORMAT")
        # Currently Views don't have a data source format defined
        if table_type in {"MANAGED", "EXTERNAL"} and source_format == "DELTA":
            return const.TableType.DELTA_TABLE
        elif table_type == "VIEW":
            return const.TableType.LOGICAL_VIEW
        else:
            return const.TableType.OTHER

    def table_exists(self, table_name: str) -> bool:
        try:
            self._get_table_info(table_name)
            return True
        except errors.DataMonitoringError as error:
            if error.error_code == errors.DataMonitoringErrorCode.TABLE_NOT_FOUND:
                return False
            raise error
