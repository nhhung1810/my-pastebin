"""
Full monitor management using the Databricks Data Monitoring service.
"""
import dataclasses
from typing import List, Union, Optional

from databricks.data_monitoring import errors, metadata
from databricks.data_monitoring.clients import base_http_client, base_monitoring_service_client
from databricks.data_monitoring.converters import metadata_json


class DatabricksMonitoringServiceClient(base_http_client.DatabricksAPIClient,
                                        base_monitoring_service_client.MonitoringServiceClient):
    """
    Client used to interact with the Data Monitoring service.
    """
    # Jinja template of path for all endpoints operating on monitors
    _DM_MONITOR_PATH_TEMPLATE = "/tables/{{ full_table_name_arg }}/monitor"
    # Jinja template of path for all endpoints operating on monitor refreshes
    _DM_REFRESH_PATH_TEMPLATE = _DM_MONITOR_PATH_TEMPLATE + "/refreshes{% if refresh_id is not none %}/{{ refresh_id }}{% endif %}"
    # Jinja template of path for all endpoints operating on profiling metrics
    _DM_METRICS_PATH_TEMPLATE = _DM_MONITOR_PATH_TEMPLATE + "/profiling-metrics"

    def __init__(self, workspace_url: str, api_token: str):
        """
        :param workspace_url: The url that can be used to invoke the workspace API, e.g.
                        e.g. "https://oregon.staging.cloud.databricks.com".
        :param api_token: Required auth token
        """
        super().__init__(
            workspace_url=workspace_url,
            api_token=api_token,
            version="2.1",
            endpoint="unity-catalog")

    def create(self,
               table_name: str,
               info: metadata.CreateMonitorInfo,
               skip_builtin_dashboard: bool = False,
               warehouse_id: Optional[str] = None) -> metadata.MonitorInfo:
        """
        Initiates a monitor creation request to the Data Monitoring service.

        :param table_name: Fully qualified table name
        :param info: CreateMonitorInfo object containing parameters to create monitor with
        :param skip_builtin_dashboard: Whether to skip creating the built-in dashboard
        :param warehouse_id: ID of the warehouse to use for dashboard creation
        :return: MonitorInfo populated with all metadata
        """
        path_params = MonitoringServiceEndpointParams(full_table_name_arg=table_name)
        method_path = self.get_method_path(
            method_template=self._DM_MONITOR_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))

        with self.get_request_session() as s:
            resp = s.post(
                self.get_method_url(method_path=method_path),
                json=metadata_json.to_create_monitor_json(
                    info=info,
                    skip_builtin_dashboard=skip_builtin_dashboard,
                    warehouse_id=warehouse_id),
                auth=self.get_auth(),
            )
        if resp.status_code == 200:
            return metadata_json.json_to_monitor_info(resp.json())
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def read(self, table_name: str) -> metadata.MonitorInfo:
        """
        Retrieves the info of a monitor from the Data Monitoring service.

        :param table_name: Fully qualified table name
        :return: MonitorInfo populated with all metadata
        """
        path_params = MonitoringServiceEndpointParams(full_table_name_arg=table_name)
        method_path = self.get_method_path(
            method_template=self._DM_MONITOR_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))
        with self.get_request_session() as s:
            resp = s.get(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code == 200:
            return metadata_json.json_to_monitor_info(resp.json())
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def update(self, table_name: str, info: metadata.MonitorInfo) -> metadata.MonitorInfo:
        """
        Updates the info of an existing monitor in the Data Monitoring service.
        
        :param table_name: Fully qualified table name
        :param info: MonitorInfo populated with updated metadata
        :return: MonitorInfo populated with all metadata
        """
        path_params = MonitoringServiceEndpointParams(full_table_name_arg=table_name)
        method_path = self.get_method_path(
            method_template=self._DM_MONITOR_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))
        with self.get_request_session() as s:
            resp = s.put(
                self.get_method_url(method_path=method_path),
                json=metadata_json.monitor_info_to_json(info=info),
                auth=self.get_auth())
        if resp.status_code == 200:
            return metadata_json.json_to_monitor_info(resp.json())
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def delete(self, table_name: str) -> None:
        path_params = MonitoringServiceEndpointParams(full_table_name_arg=table_name)
        method_path = self.get_method_path(
            method_template=self._DM_MONITOR_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))
        with self.get_request_session() as s:
            resp = s.delete(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code != 200:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def refresh(self, table_name: str) -> metadata.RefreshInfo:
        path_params = MonitoringServiceEndpointParams(full_table_name_arg=table_name)
        method_path = self.get_method_path(
            method_template=self._DM_REFRESH_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))
        with self.get_request_session() as s:
            resp = s.post(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code == 200:
            return metadata_json.json_to_refresh_info(resp.json())
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def read_refresh(self, table_name: str, refresh_id: str) -> metadata.RefreshInfo:
        path_params = MonitoringServiceEndpointParams(
            full_table_name_arg=table_name, refresh_id=refresh_id)
        method_path = self.get_method_path(
            method_template=self._DM_REFRESH_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))
        with self.get_request_session() as s:
            resp = s.get(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code == 200:
            return metadata_json.json_to_refresh_info(resp.json())
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def list_refreshes(self, table_name: str) -> List[metadata.RefreshInfo]:
        path_params = MonitoringServiceEndpointParams(full_table_name_arg=table_name)
        method_path = self.get_method_path(
            method_template=self._DM_REFRESH_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))
        with self.get_request_session() as s:
            resp = s.get(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code == 200:
            refresh_list = resp.json().get("refreshes", [])
            return list(map(metadata_json.json_to_refresh_info, refresh_list))
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def cancel_refresh(self, table_name: str, refresh_id: str) -> None:
        path_params = MonitoringServiceEndpointParams(
            full_table_name_arg=table_name, refresh_id=refresh_id)
        method_path = self.get_method_path(
            method_template=self._DM_REFRESH_PATH_TEMPLATE + "/cancel",
            method_path_params=dataclasses.asdict(path_params))
        with self.get_request_session() as s:
            resp = s.post(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code != 200:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR,
                msg=resp.text)

    def send_profiling_metrics(
            self, table_name: str,
            metrics: Union[metadata.PreRunMetrics, metadata.PostRunMetrics]) -> None:
        """
        Sends profiling job run metrics to the Data Monitoring service.

        :param table_name: Fully qualified table name
        :param metrics: Profiling job run metrics containing information like job id, error messages, etc.

        """
        path_params = MonitoringServiceEndpointParams(full_table_name_arg=table_name)
        method_path = self.get_method_path(
            method_template=self._DM_METRICS_PATH_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params))

        with self.get_request_session() as s:
            s.post(
                self.get_method_url(method_path=method_path),
                json=metadata_json.ProfilingMetricsMapper.to_json(metrics),
                auth=self.get_auth(),
            )


@dataclasses.dataclass
class MonitoringServiceEndpointParams:
    """
    Data class for holding all parameters used in rendering Data Monitoring service method
    paths.
    """
    full_table_name_arg: str
    refresh_id: str = None
