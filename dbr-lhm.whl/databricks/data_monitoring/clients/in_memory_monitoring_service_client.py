"""In-memory service client for testing."""
import dataclasses
import time
import uuid
from collections import defaultdict
from typing import List, MutableMapping, Union, Optional

from databricks.data_monitoring import metadata
from databricks.data_monitoring.clients import base_monitoring_service_client
from databricks.lakehouse_monitoring import errors


class InMemoryMonitoringServiceClient(base_monitoring_service_client.MonitoringServiceClient):
    """
    A in-memory service client suitable for tests.
    This resides here (instead of testutils) so that it's usable in DUST tests.
    """
    NON_TERMINAL_REFRESH_STATES = [metadata.RefreshState.RUNNING, metadata.RefreshState.PENDING]

    def __init__(self):
        # Collection of all monitors created in the in-memory service, with primary table name as key and
        # MonitorInfo as value, serves as the source of truth for monitor existence.
        self._store: MutableMapping[str, metadata.MonitorInfo] = {}
        # Collection of all refreshes linked to the monitors in the in-memory service, with primary table
        # name as key and sequence of RefreshInfos ordered by descending start time
        self._refresh_queues: MutableMapping[str, List[metadata.RefreshInfo]] = defaultdict(list)

    def create(self,
               table_name: str,
               info: metadata.CreateMonitorInfo,
               skip_builtin_dashboard: bool = False,
               warehouse_id: Optional[str] = None) -> metadata.MonitorInfo:
        if table_name in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor exists for {table_name}")

        # Make a copy and populate the fields that would be created by the service.
        new_info = metadata.MonitorInfo(
            profile_type=info.profile_type,
            slicing_exprs=info.slicing_exprs,
            custom_metrics=info.custom_metrics,
            baseline_table_name=info.baseline_table_name,
            output_schema_name=info.output_schema_name,
            schedule=info.schedule,
            assets_dir=info.assets_dir,
            table_name=table_name,
            status=metadata.MonitorStatus.ACTIVE,
            profile_metrics_table_name=f"{table_name}_profile_metrics_table",
            drift_metrics_table_name=f"{table_name}_drift_metrics_table",
            dashboard_id=None if skip_builtin_dashboard else str(uuid.uuid4()),
            monitor_version=0,
        )
        self._store[table_name] = new_info

        # The service is async, so it will return immediately without asset metadata
        return dataclasses.replace(
            new_info,
            status=metadata.MonitorStatus.PENDING,
            dashboard_id=None,
        )

    def read(self, table_name: str) -> metadata.MonitorInfo:
        if table_name not in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor not found for {table_name}")

        return self._store[table_name]

    def update(self, table_name: str, info: metadata.MonitorInfo) -> metadata.MonitorInfo:
        if table_name not in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor not found for {table_name}")

        self._store[table_name] = info
        return info

    def delete(self, table_name: str) -> None:
        if table_name not in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor not found for {table_name}")
        self._store.pop(table_name)

    def refresh(self, table_name: str) -> metadata.RefreshInfo:
        if table_name not in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor not found for {table_name}")

        # We will store the refresh run in RUNNING state, and immediately return the run in
        # PENDING state.
        refresh_info = metadata.RefreshInfo(
            refresh_id=str(uuid.uuid4().int),  # for getting an unique random integer id
            state=metadata.RefreshState.RUNNING,
            start_time_ms=round(time.time()),  # this field expects an int
        )

        # If there is a preceeding RUNNING refresh run, flip the status of that run to SUCCESS
        # before enqueueing the current one. So we won't have two RUNNING refresh runs in the queue.
        if len(self._refresh_queues[table_name]
               ) > 0 and self._refresh_queues[table_name][0].state == metadata.RefreshState.RUNNING:
            preceeding_refresh_info = self._refresh_queues[table_name][0]
            preceeding_refresh_info.state = metadata.RefreshState.SUCCESS
            preceeding_refresh_info.end_time_ms = refresh_info.start_time_ms

        # Latest refresh should be at top of list
        self._refresh_queues[table_name].insert(0, refresh_info)
        return dataclasses.replace(refresh_info, state=metadata.RefreshState.PENDING)

    def read_refresh(self, table_name: str, refresh_id: str) -> metadata.RefreshInfo:
        if table_name not in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor not found for {table_name}")

        refresh_infos = self._refresh_queues[table_name]
        for refresh_info in refresh_infos:
            if refresh_info.refresh_id == refresh_id:
                return refresh_info
        raise errors.LakehouseMonitoringError(f"Refresh with Id {refresh_id} not found")

    def list_refreshes(self, table_name: str) -> List[metadata.RefreshInfo]:
        if table_name not in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor not found for {table_name}")

        refresh_infos = self._refresh_queues[table_name]
        return refresh_infos

    def cancel_refresh(self, table_name: str, refresh_id: str) -> None:
        if table_name not in self._store:
            raise errors.LakehouseMonitoringError(f"Monitor not found for {table_name}")

        refresh_infos = self._refresh_queues[table_name]
        for refresh_info in refresh_infos:
            if refresh_info.refresh_id == refresh_id:
                if refresh_info.state not in self.NON_TERMINAL_REFRESH_STATES:
                    raise errors.LakehouseMonitoringError(
                        f"Refresh with Id {refresh_id} is in a terminal state")
                refresh_info.state = metadata.RefreshState.CANCELED
                refresh_info.end_time_ms = round(time.time())
                return

        raise errors.LakehouseMonitoringError(f"Refresh with Id {refresh_id} not found")

    def send_profiling_metrics(
            self, table_name: str,
            metrics: Union[metadata.PreRunMetrics, metadata.PostRunMetrics]) -> None:
        pass
