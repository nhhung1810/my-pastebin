"""
Client interface to the UC service/information. We introduce an interface instead of a http client because UC team's
recommendation is to rely on the information schema instead of direct UC calls. Unfortunately the information schema is
not available in our unit tests, which necessitates mocking of these methods.
"""
from abc import abstractmethod

from databricks.data_monitoring import const
"""Interface for retrieving UC information"""


class UcClient:
    @abstractmethod
    def get_table_type(self, table_name: str) -> const.TableType:
        """
        Retrieve the type of the table. Raise NOT_FOUND if the table name does not exist.
        :param table_name: Partially or fully-qualified table name
        :return: table type
        """
        pass

    @abstractmethod
    def table_exists(self, table_name: str) -> bool:
        """
        Check that the table exists
        :param table_name: Partially or fully-qualified table name
        :return: true iff it exists
        """
        pass
