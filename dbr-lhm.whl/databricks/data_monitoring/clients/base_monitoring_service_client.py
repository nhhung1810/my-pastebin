"""
Base class and utility methods for concrete service clients.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional, Union

from databricks.data_monitoring import metadata


class MonitoringServiceClient(ABC):
    """
    Abstract class for a client to interact with the Data Monitoring service,
    which is responsible for all operations on monitors.
    """

    @abstractmethod
    def create(self,
               table_name: str,
               info: metadata.CreateMonitorInfo,
               skip_builtin_dashboard: bool = False,
               warehouse_id: Optional[str] = None) -> metadata.MonitorInfo:
        """
        Initiates a monitor creation request to the Data Monitoring service.
        """
        pass

    @abstractmethod
    def read(self, table_name: str) -> metadata.MonitorInfo:
        """
        Retrieves the info of a monitor from the Data Monitoring service.
        """
        pass

    @abstractmethod
    def update(self, table_name: str, info: metadata.MonitorInfo) -> metadata.MonitorInfo:
        """
        Initiates a monitor update request to the Data Monitoring service.
        """

    @abstractmethod
    def delete(self, table_name: str) -> None:
        """
        Initiates a monitor deletion request to the Data Monitoring service.
        """

    @abstractmethod
    def refresh(self, table_name: str) -> metadata.RefreshInfo:
        """
        Initiates a metric refresh request for a monitor to the Data Monitoring service.
        """

    @abstractmethod
    def read_refresh(self, table_name: str, refresh_id: str) -> metadata.RefreshInfo:
        """
        Retrieves the info of a metric refresh run from the Data Monitoring service.
        """

    @abstractmethod
    def list_refreshes(self, table_name: str) -> List[metadata.RefreshInfo]:
        """
        Retrieves the info of recent metric refresh runs as a list from the Data Monitoring service.
        """

    @abstractmethod
    def cancel_refresh(self, table_name: str, refresh_id: str) -> None:
        """
        Initiaties a cancel refresh request for a refresh in a non-terminal state to the Data Monitoring service.
        """

    @abstractmethod
    def send_profiling_metrics(
            self, table_name: str,
            metrics: Union[metadata.PreRunMetrics, metadata.PostRunMetrics]) -> None:
        """
        Send observability of current job run back to the Data Monitoring service.
        """
