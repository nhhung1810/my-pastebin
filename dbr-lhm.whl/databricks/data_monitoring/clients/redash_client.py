"""
Interface for retrieving data from the redash service
"""
from abc import abstractmethod


class RedashClient:
    @abstractmethod
    def get_dashboard(self, dashboard_id) -> dict:
        """
        Fetches the dashboard from DBSQL service.

        :param dashboard_id: The dashboard id.
        :return: The dashboard.
        """
        pass
