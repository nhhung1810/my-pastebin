"""
Client to fetch data from DBSQL service.
"""
import dataclasses

from databricks.data_monitoring import errors
from databricks.data_monitoring.clients import base_http_client, redash_client


class DatabricksRedashClient(base_http_client.DatabricksAPIClient, redash_client.RedashClient):
    _DBSQL_DASHBOARD_ENDPOINT_TEMPLATE = "/dashboards/{{ dashboard_id }}"

    def __init__(self, workspace_url: str, api_token: str):
        """
        :param workspace_url: The url that can be used to invoke the workspace API, e.g.
                        e.g. "https://oregon.staging.cloud.databricks.com".
        :param api_token: Required auth token
        """
        super().__init__(
            workspace_url=workspace_url, api_token=api_token, version="2.0", endpoint="sql")

    def get_dashboard(self, dashboard_id: str) -> dict:
        """
        Fetches the dashboard from DBSQL service.

        :param dashboard_id: The dashboard id returned from monitoring service
        """
        path_params = DashboardGetParams(dashboard_id=dashboard_id)
        method_path = self.get_method_path(
            method_template=self._DBSQL_DASHBOARD_ENDPOINT_TEMPLATE,
            method_path_params=dataclasses.asdict(path_params),
            is_preview=True)
        with self.get_request_session() as s:
            resp = s.get(
                self.get_method_url(method_path=method_path),
                json={},
                auth=self.get_auth(),
            )
        if resp.status_code == 200:
            return resp.json()
        else:
            raise errors.DataMonitoringError(
                error_code=errors.DataMonitoringErrorCode.DASHBOARD_SERVICE_ERROR, msg=resp.text)


@dataclasses.dataclass
class DashboardGetParams:
    """
    Data class for parameters used to fetch dashboards from DBSQL service.
    """
    dashboard_id: str
