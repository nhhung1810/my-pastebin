"""
Representation and JSON-serder for data-monitoring metadata.

Make new fields as optional if possible to be backward compatible. If the new optional field has a
default value, we can choose one of the following approaches to specify the default value:
1) Set the default value of the optional field in the schema.
2) Set the default value of the optional field in the schema to be None. Modify the
ModelRegistryMetadataStoreClient.read method to set the default value before returning the monitor
configuration.

Note that if the downstream jobs rely on the new optional field and we cannot set the default value
for it, we need to check the existence of the field first before executing the job.
"""

from __future__ import annotations  # To enable a class method to return an instance of itself

import enum
import json
import pydantic
from pydantic.json import custom_pydantic_encoder
from typing import Any, List, Optional, Union

from pyspark.sql import types as T

from databricks.data_monitoring import metrics, const
from databricks.data_monitoring.analysis import Snapshot, TimeSeries, InferenceLog


def _repr_encoder(obj: Any) -> Any:
    """
    An encoder to be used to serialize a pydantic dataclass to a
    human-readable string. For certain fields (e.g. Spark data types),
    we need special logic - each of these should be specified in the
    `type_encoders` dictionary passed to the custom_pydantic_encoder.

    :param obj: The object to encode
    :return: The encoded version of the object
    """
    type_encoders = {T.DataType: lambda o: o.jsonValue()}
    return custom_pydantic_encoder(type_encoders, obj)


# Keep in sync with MonitorStatus enum variable in proto definitions
class MonitorStatus(str, enum.Enum):
    """
    Tracks the status of an existing monitor
    """

    ACTIVE = "MONITOR_STATUS_ACTIVE"
    """The monitor is active and works as expected"""

    PENDING = "MONITOR_STATUS_PENDING"
    """The monitor is being updated. Its state might be inconsistent and cannot be used"""

    DELETE_PENDING = "MONITOR_STATUS_DELETE_PENDING"
    """The monitor is being deleted. Its state might be inconsistent and cannot be used"""

    ERROR = "MONITOR_STATUS_ERROR"
    """
    An operation on the monitor has resulted in a recoverable error. Details for the error can be found in the monitor 
    information (see :py:func:`databricks.lakehouse_monitoring.get_monitor`). The user may be able to fix the error by 
    updating the monitor.
    """

    FAILED = "MONITOR_STATUS_FAILED"
    """
    An operation on the monitor has resulted in a non-recoverable error. Details can be found in the monitor 
    information (see :py:func:`databricks.lakehouse_monitoring.get_monitor`). The user can only delete the monitor and 
    re-create it if needed.
    """


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class MonitorCronSchedule:
    """
    The refresh schedule for the monitor.
    """

    quartz_cron_expression: str
    """
    The expresssion that determines when to run the monitor. See  `examples 
    <https://www.quartz-scheduler.org/documentation/quartz-2.3.0/tutorials/crontrigger.html>`_
    """

    timezone_id: str
    """The timezone id (e.g., ``"PST"``) in which to evaluate the quartz expression."""

    def __repr__(self) -> str:
        return json.dumps(self, indent=4, default=_repr_encoder)


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class MonitorInfo:
    """
    All monitor information, i.e. the configuration, assets, and status of the monitor.
    """

    table_name: str
    """Name of monitored table."""

    profile_type: Union[InferenceLog, TimeSeries, Snapshot]
    """
    The type of profiling done on the table. This determines the metrics computed by monitoring. See
    :py:func:`databricks.lakehouse_monitoring.create_monitor` for further details. 
    """

    output_schema_name: Optional[str]
    """
    Name of the schema in which to store the output metric tables. This may be None if the output schema is inaccessible
    after the monitor creation.
    """

    status: MonitorStatus
    """Status of the monitor."""

    profile_metrics_table_name: str
    """Name of table holding the profile metrics."""

    drift_metrics_table_name: str
    """Name of table holding the drift metrics."""

    monitor_version: int
    """
    Version number of the monitor configuration used in the refresh pipeline.
    """

    baseline_table_name: Optional[str] = None
    """
    Baseline table against which to compare the input table. See
    :py:func:`databricks.lakehouse_monitoring.create_monitor` for further details.
    """

    schedule: Optional[MonitorCronSchedule] = None
    """
    Schedule on which to run refreshes on the monitor.
    """

    slicing_exprs: Optional[List[str]] = None
    """
    Expressions that determine data slices on which to compute metrics. See
    :py:func:`databricks.lakehouse_monitoring.create_monitor` for further details. 
    """

    custom_metrics: Optional[List[metrics.Metric]] = None
    """
    Custom metrics that are computed in addition to the built-in metrics. See
    :py:class:`databricks.lakehouse_monitoring.Metric` for further details. 
    """

    assets_dir: Optional[str] = None
    """
    The workspace directory that stores monitoring assets, including the
    dashboard and its associated queries.
    """

    dashboard_id: Optional[str] = None
    """
    Id of dashboard that visualizes the computed metrics.
    This can be empty if the monitor is in PENDING state.
    """

    latest_monitor_failure_msg: Optional[str] = None
    """Failure reason if the `MonitorStatus` is FAILED """

    def __repr__(self) -> str:
        return json.dumps(self, indent=4, default=_repr_encoder)


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class CreateMonitorInfo:
    """
    Monitor information necessary to make a CreateMonitor request.
    This class should be a strict subset of `MonitorInfo`, specifically missing
    fields that are not meant to be set by the caller, meant for internal usage
    by our service client. Since our service protos use a unified DataMonitorInfo
    message, it's extremely important that this class does not deviate from
    the MonitorInfo class on the fields that they share.
    """
    profile_type: Union[InferenceLog, TimeSeries, Snapshot]
    output_schema_name: Optional[str] = None
    baseline_table_name: Optional[str] = None
    schedule: Optional[MonitorCronSchedule] = None
    slicing_exprs: Optional[List[str]] = None
    custom_metrics: Optional[List[metrics.Metric]] = None
    assets_dir: Optional[str] = None


# Keep in sync with RefreshState enum variable in proto definitions
class RefreshState(str, enum.Enum):
    """Different states for a refresh operation"""

    PENDING = "PENDING"
    """The refresh has been initiated, but is waiting to run."""

    RUNNING = "RUNNING"
    """The refresh is in progress."""

    SUCCESS = "SUCCESS"
    """
    The refresh finished successfully without any errors. This is a terminal state.
    """

    FAILED = "FAILED"
    """
    An error occurred during refresh. This is a terminal state.
    """

    CANCELED = "CANCELED"
    """
    The refresh was canceled. This is a terminal state.
    """


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class RefreshInfo:
    """Information for a refresh operation of the output metrics."""

    refresh_id: str
    """Unique id of the refresh operation."""

    state: RefreshState
    """State (:py:class:`databricks.lakehouse_monitoring.RefreshState`) of the refresh operation."""

    start_time_ms: int
    """Time at which refresh operation was initiated (milliseconds since 1/1/1970 UTC)."""

    end_time_ms: Optional[int] = None
    """Time at which refresh operation completed (milliseconds since 1/1/1970 UTC)."""

    message: Optional[str] = None
    """
    An optional message that provides more information about the current status of the refresh.
    """


class ProfilingState(str, enum.Enum):
    """Different terminal states for a profiling job run"""

    SUCCESS = "PROFILING_STATE_SUCCESS"
    """The profiling job terminated without any errors."""

    FAILED = "PROFILING_STATE_FAILED"
    """The profiling job terminated with errors."""


class RunnerType(str, enum.Enum):
    """Different terminal states for a profiling job run"""

    UNASSIGNED = "RUNNER_TYPE_UNASSIGNED"
    """The profiling job haven't assigned runner type this the run"""

    BASE = "RUNNER_TYPE_BASE"
    """The profiling job choose base runner for this run."""

    FULL = "RUNNER_TYPE_FULL"
    """The profiling job choose full runner for this run."""

    INCREMENTAL = "RUNNER_TYPE_INCREMENTAL"
    """The profiling job choose incremental runner for this run."""


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class PreRunMetrics:
    """Profiling metrics collected right before the profiler starts"""

    job_id: Optional[str] = None
    """Unique id of the profiling job."""

    run_id: Optional[str] = None
    """Unique id of the profiling job run."""

    table_size: Optional[int] = None
    """Size of the primary table in bytes"""


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class PostRunMetrics:
    """Profiling metrics collected at the end of the profiler job"""

    state: ProfilingState
    """Status of the profiling job"""

    runner_type: RunnerType
    """The chosen runner type for this run"""

    job_id: Optional[str] = None
    """Unique id of the profiling job."""

    run_id: Optional[str] = None
    """Unique id of the profiling job run."""

    error_code: Optional[str] = None
    """Profiling error code when running into failed state"""

    error_msg: Optional[str] = None
    """Detailed error message when running into failed state"""

    error_trace: Optional[str] = None
    """Exception traceback when running into failed state"""


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class ProfilingConfs:
    """Profiling configurations to apply during refresh."""

    drift_metrics_filter_threshold_days: Optional[int] = None
    """Filters the profile metrics in order to limit computed drift metrics to a rolling window"""

    profiling_filter_timestamp: Optional[int] = None
    """
    Timestamp used to filter old input data before profiling. 
    """
