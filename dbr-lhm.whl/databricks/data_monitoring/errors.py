"""
Error reporting for data-monitoring API and implementation.

We centralize error classes and error messages here so that it's easier to reason (and test) about the error
cases across the code.
"""
from enum import Enum, unique
from typing import Iterable


@unique
class DataMonitoringErrorCode(str, Enum):
    """
    Enum class for Data Monitoring error codes.
    """
    UNKNOWN = "UNKNOWN"
    NO_AVAILABLE_CONTEXT = "NO_AVAILABLE_CONTEXT"
    CONTEXT_ALREADY_SET = "CONTEXT_ALREADY_SET"
    RUNTIME_NOT_SUPPORTED = "RUNTIME_NOT_SUPPORTED"
    MONITOR_EXISTS = "MONITOR_EXISTS"
    MONITOR_NOT_FOUND = "MONITOR_NOT_FOUND"
    MULTIPLE_MONITORS_FOUND = "MULTIPLE_MONITORS_FOUND"
    METADATA_FIELD_LENGTH_LIMIT_EXCEEDED = "METADATA_FIELD_LENGTH_LIMIT_EXCEEDED"
    NON_NULLABLE_METADATA_FIELD_EMPTY = "NON_NULLABLE_METADATA_FIELD_EMPTY"
    IMMUTABLE_METADATA_FIELD_CHANGED = "IMMUTABLE_METADATA_FIELD_CHANGED"
    METADATA_PRIVILEGE_GRANT_FAILED = "METADATA_PRIVILEGE_GRANT_FAILED"
    METADATA_SCHEMA_EMPTY = "METADATA_SCHEMA_EMPTY"
    METADATA_FIELD_NOT_FOUND = "METADATA_FIELD_NOT_FOUND"
    MODEL_NOT_FOUND = "MODEL_NOT_FOUND"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    # Input parameters related errors.
    TABLE_COLUMN_NOT_FOUND = "TABLE_COLUMN_NOT_FOUND"
    BASELINE_TABLE_COLUMN_NOT_FOUND = "BASELINE_TABLE_COLUMN_NOT_FOUND"
    INVALID_ANALYSIS_TYPE = "INVALID_ANALYSIS_TYPE"
    INVALID_AGG_GRANULARITY = "INVALID_AGG_GRANULARITY"
    INVALID_ID_COLUMNS = "INVALID_ID_COLUMNS"
    INVALID_LABEL_COL = "INVALID_LABEL_COL"
    INVALID_MONITOR_NAME = "INVALID_MONITOR_NAME"
    INVALID_PROBLEM_TYPE = "INVALID_PROBLEM_TYPE"
    INVALID_SLICING_EXPRESSION = "INVALID_SLICING_EXPRESSION"
    INVALID_LINKED_ENTITY = "INVALID_LINKED_ENTITY"
    SCHEMA_NOT_FOUND = "SCHEMA_NOT_FOUND"
    OUTPUT_SCHEMA_IN_HIVE_METASTORE = "OUTPUT_SCHEMA_IN_HIVE_METASTORE"
    INSUFFICIENT_MODEL_PERMISSIONS = "INSUFFICIENT_MODEL_PERMISSIONS"
    CONFIG_MISSING_EXAMPLE_ID = "CONFIG_MISSING_EXAMPLE_ID"
    MISSING_EXAMPLE_ID = "MISSING_EXAMPLE_ID"
    LABEL_COL_NOT_FOUND = "LABEL_COL_NOT_FOUND"
    PREDICTION_LABEL_COL_OVERLAP = "PREDICTION_LABEL_COL_OVERLAP"
    MISSING_REQUIRED_LOGGING_SCHEMA_COLS = "MISSING_REQUIRED_LOGGING_SCHEMA_COLS"
    NOT_A_DIRECTORY = "NOT_A_DIRECTORY"
    PREDICTION_LABEL_TYPE_PROBLEM_TYPE_MISMATCH = "PREDICTION_LABEL_TYPE_PROBLEM_TYPE_MISMATCH"
    # Input table related errors.
    TABLE_NOT_FOUND = "TABLE_NOT_FOUND"
    TABLE_FOUND = "TABLE_FOUND"
    INVALID_TABLE_NAME_FORMAT = "INVALID_TABLE_NAME_FORMAT"
    EMPTY_BASELINE_DATA = "EMPTY_BASELINE_DATA"
    # Metrics related errors.
    COLUMN_SPEC_MISCONFIGURED = "COLUMN_SPEC_MISCONFIGURED"
    INVALID_CUSTOM_METRIC_TYPE = "INVALID_CUSTOM_METRIC_TYPE"
    INVALID_CUSTOM_METRIC_OBJECT = "INVALID_CUSTOM_METRIC_OBJECT"
    # Rendering related errors.
    COLUMN_TYPE_NOT_SUPPORTED = "COLUMN_TYPE_NOT_SUPPORTED"
    INCOMPATIBLE_LOGGING_FIELDS = "INCOMPATIBLE_LOGGING_FIELDS"
    VALUE_ERROR = "VALUE_ERROR"
    # Backend related errors.
    JOBS_CLIENT_ERROR = "JOBS_CLIENT_ERROR"
    PIPELINES_CLIENT_ERROR = "PIPELINES_CLIENT_ERROR"
    WORKSPACE_CLIENT_ERROR = "WORKSPACE_CLIENT_ERROR"
    DATA_MONITORING_SERVICE_ERROR = "DATA_MONITORING_SERVICE_ERROR"
    MAX_NOTEBOOK_SIZE_EXCEEDED = "MAX_NOTEBOOK_SIZE_EXCEEDED"
    PERMISSION_UPDATE_FAILED = "PERMISSION_UPDATE_FAILED"
    GET_REGISTERED_MODEL_ERROR = "GET_REGISTERED_MODEL_ERROR"
    # Job Status Related errors
    RUN_WAIT_TIMED_OUT = "RUN_WAIT_TIMED_OUT"
    RUN_DID_NOT_SUCCEED = "RUN_DID_NOT_SUCCEED"
    # Other errors
    RESOURCE_ALREADY_EXISTS = "RESOURCE_ALREADY_EXISTS"
    INVALID_UPDATE_PARAM = "INVALID_UPDATE_PARAM"
    UPDATE_IMMUTABLE_CONFIG = "UPDATE_IMMUTABLE_CONFIG"
    DUPLICATE_COLUMNS = "DUPLICATE_COLUMNS"
    DBSQL_CLIENT_ERROR = "DBSQL_CLIENT_ERROR"
    DBSQL_ENTITLEMENT_MISSING = "DBSQL_ENTITLEMENT_MISSING"
    INVALID_INPUT_TABLE_SCHEMA = "INVALID_INPUT_TABLE_SCHEMA"
    INVALID_SCHEMA_NAME_FORMAT = "INVALID_SCHEMA_NAME_FORMAT"
    DASHBOARD_SERVICE_ERROR = "DASHBOARD_SERVICE_ERROR"


# TODO [ML-19148]: Create high-level error subclasses
class DataMonitoringError(Exception):
    """
    Exception class for Data Monitoring errors.
    """

    # Mapping of error codes to pre-formatted error messages that must be filled with kwargs.
    ERROR_CODE_TO_MESSAGE = {
        DataMonitoringErrorCode.UNKNOWN: "{msg}",
        DataMonitoringErrorCode.NO_AVAILABLE_CONTEXT: "No available context. Please set a new context.",
        DataMonitoringErrorCode.CONTEXT_ALREADY_SET: "Context is already set, please clear the current context "
        "before setting a new one.",
        DataMonitoringErrorCode.RUNTIME_NOT_SUPPORTED: "Data Monitoring only supports clusters with"
        " Unity Catalog enabled.",
        DataMonitoringErrorCode.MONITOR_EXISTS: "Monitor for table '{table_name}' already exists.",
        DataMonitoringErrorCode.MONITOR_NOT_FOUND: "No monitor found for table '{table_name}'.",
        DataMonitoringErrorCode.MULTIPLE_MONITORS_FOUND: "Multiple monitors found for model '{model_name}' and "
        "monitor name '{monitor_name}'. Please ensure there are no "
        "duplicate entries.",
        DataMonitoringErrorCode.METADATA_FIELD_LENGTH_LIMIT_EXCEEDED: "Metadata field '{field}' exceeds length limit "
        "of {limit}. Please reduce the length and try "
        "again.",
        DataMonitoringErrorCode.METADATA_SCHEMA_EMPTY: "No variables are defined in {msg}",
        DataMonitoringErrorCode.METADATA_FIELD_NOT_FOUND: "Metadata fields are missing. {msg}",
        DataMonitoringErrorCode.NON_NULLABLE_METADATA_FIELD_EMPTY: "Field {field} is non-nullable and must be set "
        "during creation.",
        DataMonitoringErrorCode.IMMUTABLE_METADATA_FIELD_CHANGED: "Metadata field '{field}' is immutable and cannot "
        "be updated.",
        DataMonitoringErrorCode.METADATA_PRIVILEGE_GRANT_FAILED: "Error granting privileges to global metadata table "
        "for all users:\n{grant_msg}",
        DataMonitoringErrorCode.MODEL_NOT_FOUND: "Model '{model_name}' was not found in the model registry. Please "
        "choose a different model.",
        DataMonitoringErrorCode.TABLE_COLUMN_NOT_FOUND: "Cannot find following columns in the table schema"
        "{table_schema}: {columns}",
        DataMonitoringErrorCode.BASELINE_TABLE_COLUMN_NOT_FOUND: "Cannot find following columns in the baseline table schema"
        "{baseline_table_schema}: {columns}",
        DataMonitoringErrorCode.INVALID_ANALYSIS_TYPE: "There was en error initializing the analysis type for the monitor. {message}",
        DataMonitoringErrorCode.INVALID_AGG_GRANULARITY: "Invalid set of granularities provided for analysis type "
        "{analysis_type}: {granularities}. Granularities must be None for analysis type `Generic`. For other "
        "analysis types: granularities must be a subset of {valid_granularities} or n units of "
        "{valid_var_granularities} (1<=n<=4).",
        DataMonitoringErrorCode.INVALID_ID_COLUMNS: "The specified example-id columns are invalid: {msg}",
        DataMonitoringErrorCode.INVALID_LABEL_COL: "The `label_col='{col}'` argument does not match the "
        "monitor configuration which expects the label in column '{config_col}'. Rename the column "
        "(e.g., use `withColumnRenamed` on the input dataframe) and retry.",
        DataMonitoringErrorCode.INVALID_MONITOR_NAME: "The specified monitor name is invalid: {msg}",
        DataMonitoringErrorCode.INVALID_PROBLEM_TYPE: "The specified problem type '{problem_type}' is invalid. Must be"
        " one of ['classification', 'regression'].",
        DataMonitoringErrorCode.INVALID_SLICING_EXPRESSION: "The specified slicing expression is "
        "invalid: {slicing_expr}. {msg}",
        DataMonitoringErrorCode.INVALID_LINKED_ENTITY: "The format of the `{linked_entity}` is not valid.",
        DataMonitoringErrorCode.SCHEMA_NOT_FOUND: "Cannot find the specified schema '{schema}'. Check that it exists or"
        " use `%sql CREATE SCHEMA <schema_name>` to create a new one.",
        DataMonitoringErrorCode.OUTPUT_SCHEMA_IN_HIVE_METASTORE: "Output schemas registered in Hive metastore are not supported. Please provide or use a catalog registered in Unity Catalog.",
        DataMonitoringErrorCode.INSUFFICIENT_MODEL_PERMISSIONS: "CAN_MANAGE permission level is required in order to "
        "delete monitor for model '{model_name}'.",
        DataMonitoringErrorCode.COLUMN_SPEC_MISCONFIGURED: "Exactly one of `column_names` and `column_types` can be"
        " filled.",
        # TODO(ML-YYYY): Update the error message once the API to update configuration is in place.
        DataMonitoringErrorCode.CONFIG_MISSING_EXAMPLE_ID: "Example-id columns not configured for "
        "model_name='{model_name}' monitor_name='{monitor_name}'. Please ask the owner to update the monitor "
        "configuration.",
        DataMonitoringErrorCode.MISSING_EXAMPLE_ID: "Could not identify example-id columns in the provided data for "
        "model_name='{model_name}' and monitor_name='{monitor_name}'. {msg}",
        DataMonitoringErrorCode.LABEL_COL_NOT_FOUND: "Could not identify label column in the provided data. Use "
        "`label_col=...` and retry.",
        DataMonitoringErrorCode.PREDICTION_LABEL_COL_OVERLAP: "Prediction and label column must be distinct.",
        DataMonitoringErrorCode.MISSING_REQUIRED_LOGGING_SCHEMA_COLS: "Column '{col}' must be specified in "
        "the provided `logging_schema`. Please add it and try again.",
        DataMonitoringErrorCode.NOT_A_DIRECTORY: "The provided path for data monitoring assets is not a directory: "
        "{path}.",
        DataMonitoringErrorCode.COLUMN_TYPE_NOT_SUPPORTED: "{msg}: unsupported column type '{column_type}'.",
        DataMonitoringErrorCode.INCOMPATIBLE_LOGGING_FIELDS: "One or more columns from the provided DataFrame have "
        "incompatible data types with the schema of the Logging Table. Please convert the mistyped columns to the "
        "appropriate data type. Underlying error message: \"{msg}\"",
        DataMonitoringErrorCode.VALUE_ERROR: "Value error: {msg}.",
        DataMonitoringErrorCode.JOBS_CLIENT_ERROR: "Unable to '{api}' job: {msg}",
        DataMonitoringErrorCode.PIPELINES_CLIENT_ERROR: "Unable to '{api}' pipeline: {msg}",
        DataMonitoringErrorCode.WORKSPACE_CLIENT_ERROR: "Unable to perform '{api}' operation at '{path}': {msg}",
        DataMonitoringErrorCode.DATA_MONITORING_SERVICE_ERROR: "Unable to perform data monitoring service request: "
        "{msg}",
        DataMonitoringErrorCode.MAX_NOTEBOOK_SIZE_EXCEEDED: "Notebook content size limit exceeded: {msg}",
        DataMonitoringErrorCode.PERMISSION_UPDATE_FAILED: "Unable to update permissions of object "
        "'{object_id}': {msg}",
        DataMonitoringErrorCode.GET_REGISTERED_MODEL_ERROR: "Unable to get registered model '{model_name}': {msg}",
        DataMonitoringErrorCode.RUN_WAIT_TIMED_OUT: "Timed out while waiting for run. Run last seen in state: "
        "{state}.",
        DataMonitoringErrorCode.RUN_DID_NOT_SUCCEED: "Run did not succeed, terminated with result state: {state}.",
        DataMonitoringErrorCode.RESOURCE_ALREADY_EXISTS: "Resource already exists at {path}.",
        DataMonitoringErrorCode.EMPTY_BASELINE_DATA: "Baseline data found in monitor is empty.",
        DataMonitoringErrorCode.INVALID_UPDATE_PARAM: "Invalid param(s) for monitor update: '{params}'."
        " {msg}",
        DataMonitoringErrorCode.UPDATE_IMMUTABLE_CONFIG: "Could not update immutable field(s): '{config}'."
        " To change these fields, please create a new monitor.",
        DataMonitoringErrorCode.DUPLICATE_COLUMNS: "Cannot rename 'prediction_col' or 'label_col' to "
        "an existing column of the Logging Tables.",
        DataMonitoringErrorCode.INVALID_CUSTOM_METRIC_TYPE: "Invalid custom metric type. The metric_type must be "
        "one of `aggregate`, `derived` or `drift`",
        DataMonitoringErrorCode.PREDICTION_LABEL_TYPE_PROBLEM_TYPE_MISMATCH: "{column} has invalid type {column_type}."
        "Prediction and label type must both be subclasses of one of the following: {valid_types} for models "
        "of type: {problem_type}. Note, if you would like to track other quality metrics (such as output "
        "probabilities for classification models), please add them in another field and track "
        "them through Custom Metrics.",
        # This message does not indicate what are allowed characters in the table name.
        # Please update the message if needed.
        DataMonitoringErrorCode.INVALID_TABLE_NAME_FORMAT: "Table name '{table_name}' has invalid format. "
        "Please specify it as catalog.schema.table, schema.table, or table.",
        DataMonitoringErrorCode.INVALID_SCHEMA_NAME_FORMAT: "Schema name '{name}' has invalid format. "
        "Please specify it as 'catalog.schema', or 'schema'.",
        DataMonitoringErrorCode.INVALID_INPUT_TABLE_SCHEMA: "'{column_names}' are reserved by data monitoring. However, they are used in the input table. Please try to rename these columns and call the API again.",
        DataMonitoringErrorCode.DBSQL_CLIENT_ERROR: "Databricks SQL client cannot {action}: {msg}.",
        DataMonitoringErrorCode.DBSQL_ENTITLEMENT_MISSING: "You do not have access to Databricks SQL in this workspace, which is required for the dashboard generated by data monitoring. Please contact your admin to gain access and re-run the data-monitoring command.",
        DataMonitoringErrorCode.TABLE_NOT_FOUND: "Cannot find table '{table_name}'.",
        DataMonitoringErrorCode.TABLE_FOUND: "Table already exists: {table_name}. {msg}",
        DataMonitoringErrorCode.INTERNAL_ERROR: "Internal error. Please contact the Databricks team for further "
        "assistance and include this message: {message}",
        DataMonitoringErrorCode.DASHBOARD_SERVICE_ERROR: "An error occurred in the dashboard service. Please contact the Databricks team for further assistance.",
    }

    def __init__(self, *, error_code: DataMonitoringErrorCode, **message_kwargs):
        if not isinstance(error_code, DataMonitoringErrorCode):
            raise DataMonitoringErrorCode(
                error_code=DataMonitoringErrorCode.INTERNAL_ERROR,
                message=f"Error code must be of type DataMonitoringErrorCode. Given: {error_code}")
        self.error_code = error_code
        self.is_internal = self.error_code in (DataMonitoringErrorCode.NO_AVAILABLE_CONTEXT,
                                               DataMonitoringErrorCode.CONTEXT_ALREADY_SET)
        self.message = self.ERROR_CODE_TO_MESSAGE.get(error_code, "").format(**message_kwargs)

        super().__init__(self.message)


def quoted_column_list(cols: Iterable[str]) -> str:
    """
    Returns a string representation of the input column names.
    :param cols: Column names, e.g., ["a", "b"]
    :return: a comma-separated string of the quoted column names, e.g., "'a','b'".
    """
    return ",".join([f"'{col}'" for col in sorted(cols)])
