"""Custom metrics definition module."""
from typing import List, Union

import pydantic
from pyspark.sql import types as T

from databricks.data_monitoring import const


@pydantic.dataclasses.dataclass(config=const.PydanticConfig)
class Metric:
    """
    Definition of a custom metric. Examples:

    - An aggregate metric that only applies to column ``f1``. It computes the avg of the log of the target column:

        >>> agg_metric = Metric(
            type="aggregate",
            name="avg_log",
            input_columns=["f1"],
            definition="avg(log(`{{input_column}}`))",
            output_data_type=T.DoubleType())

    - An aggregate metric that is calculated using multiple columns. It computes the avg of the difference between
      columns ``f1`` and ``f2``:

        >>> agg_metric = Metric(
            type="aggregate",
            name="avg_diff_f1_f2",
            input_columns=[":table"],
            definition="avg(f1 - f2)",
            output_data_type=T.DoubleType())

    - A derived metric that depends on metric ``avg_log``. It computes the exp exponential of the ``avg_log`` metric:

        >>> derived_metric = Metric(
            type="derived",
            name="exp_avg_log",
            input_columns=["f1"],
            definition="exp(avg_log)",
            output_data_type=T.DoubleType())

    - A drift metric that depends on metric ``avg_log``. It computes the diff between the ``avg_log`` metrics across
      baseline and input table, and across the two consecutive time windows:

        >>> drift_metric = Metric(
            type="drift",
            name="avg_log_delta",
            input_columns=["f1"],
            definition="{{current_df}}.avg_log - {{base_df}}.avg_log",
            output_data_type=T.DoubleType())
    """

    type: str
    """
    Can only be one of ``"aggregate"``, ``"derived"``, or ``"drift"``. The ``"aggregate"`` and ``"derived"`` metrics
    are computed on a single table, whereas the ``"drift"`` compare metrics across
    baseline and input table, or across the two consecutive time windows.
    
                   - aggregate metrics: only depend on the existing columns in your table
                   - derived metrics: depend on previously computed aggregate metrics
                   - drift metrics:  depend on previously computed aggregate or derived metrics
    """

    name: str
    """
    Name of the metric in the output tables
    """

    input_columns: Union[List[str], str]
    """
    A list of column names in the input table the metric should be computed for.
    Can use ``":table"`` to indicate that the metric needs information from multiple columns.
    """

    definition: str
    """
    A SQL expression jinja template that defines the computation of the metric.
    Supported template parameters:
    
                         - ``{{input_column}}`` : name of the column on which the metric is computed
                         - ``{{prediction_col}}`` : name of the ML model prediction column
                         - ``{{label_col}}`` : name of the ML ground truth label column
                         - ``{{current_df}}`` / ``{{base_df}}`` : Alias of the datasets being compared for drift metrics.
                            For BASELINE drift, ``{{base_df}}`` will represent the baseline data;
                            for CONSECUTIVE drift, ``{{base_df}}`` will represent data from the previous time window.
    """

    output_data_type: T.DataType
    """
    Spark datatype of the metric output.
    """
