from typing import Iterator, Tuple
from databricks.data_monitoring.context import Context
from databricks.data_monitoring import analysis, metadata


def link_for_table(table_name: str, description: str) -> str:
    """Returns a link for the table's data-explorer page, using the given description for the text of the link"""
    table_path = table_name.replace(".", "/")
    return f"<a href=\"/explore/data/{table_path}\">{description}</a>"


def get_dashboard_filter_defaults(info: metadata.MonitorInfo) -> Iterator[Tuple[str, str]]:
    """Returns defaults for any dashboard filters that may apply to passed monitor"""
    parameters = [('Slice key', 'No slice'), ('Slice value', 'No slice')]

    profile_type = info.profile_type

    if isinstance(profile_type, (analysis.InferenceLog, analysis.TimeSeries)):
        parameters.append(('Granularity', profile_type.granularities[0]))

    if isinstance(profile_type, analysis.InferenceLog):
        parameters.append(('Model Id', '*'))

    return parameters


def get_dashboard_filter_guids(dashboard: dict) -> dict:
    """Returns a dictionary mapping dashboard filter titles to their guids"""
    widgets = dashboard["widgets"]
    dashboard_guid_by_title = {}

    for w in widgets:
        if w.get("dashboard_filter_config"):
            dashboard_guid_by_title[w["options"]["title"]] = w["id"]

    return dashboard_guid_by_title


def link_for_dashboard(info: metadata.MonitorInfo, description: str) -> str:
    """Returns a link for the dashboard with the given id, using the given description for the text of the link"""
    dashboard_id = info.dashboard_id

    try:
        dashboard = Context.redash_client.get_dashboard(dashboard_id)
        dashboard_filter_guids = get_dashboard_filter_guids(dashboard)
        dashboard_filter_defaults = get_dashboard_filter_defaults(info)

        # "f_" is a prefix that redash uses to denote filter parameters
        parameters = [[f"f_{dashboard_filter_guids[title]}", value]
                      for title, value in dashboard_filter_defaults
                      if title in dashboard_filter_guids]

        search_urls = '&'.join([f'{guid}={value}' for guid, value in parameters])

        return f"<a href=\"/sql/dashboards/{dashboard_id}?{search_urls}\">{description}</a>"
    except Exception as e:
        return f"<a href=\"/sql/dashboards/{dashboard_id}\">{description}</a>"


def display_assets(info: metadata.MonitorInfo) -> None:
    """
    Displays HTML links to monitoring assets (i.e. dashboard and metric tables).

    :param info: Monitor info
    :return: None
    """

    profile_metrics_table_link = link_for_table(info.profile_metrics_table_name,
                                                "profile metrics table")
    drift_metrics_table_link = link_for_table(info.drift_metrics_table_name, "drift metrics table")

    if info.dashboard_id is not None:
        dashboard_link = link_for_dashboard(info, "dashboard")

        assets_message = (
            f"Monitoring metrics can be visualized through the {dashboard_link} or queried from "
            f"the {profile_metrics_table_link} and {drift_metrics_table_link}.")

        if not Context.uc_client.table_exists(info.profile_metrics_table_name) or \
                not Context.uc_client.table_exists(info.drift_metrics_table_name):
            assets_message += f" Note that a refresh must succeed in order for " \
                              f"the metric tables to exist and the dashboard to be functional."

        Context.display_html(assets_message)
    else:
        Context.display_html(f"Monitoring metrics can be queried from the "
                             f"{profile_metrics_table_link} and {drift_metrics_table_link}.")


def display_lingering_assets(info: metadata.MonitorInfo) -> None:
    """
    Displays HTML links to any assets lingering after monitor deletion, so that the user can remove them manually
    if needed.

    :param info:
    """
    links = []

    if info.profile_metrics_table_name is not None:
        links.append(link_for_table(info.profile_metrics_table_name, "Profile metrics table"))
    if info.drift_metrics_table_name is not None:
        links.append(link_for_table(info.drift_metrics_table_name, "Drift metrics table"))
    if info.dashboard_id is not None:
        links.append(link_for_dashboard(info, "Dashboard"))

    if links:
        Context.display_html(f"""
            <b>Note</b>: The monitor was deleted but not its output assets. The following assets still exist and you can
             delete them manually if desired:
            <ul>
              {" ".join([f"<li>{link}</li>" for link in links])}
            </ul>
        """)
