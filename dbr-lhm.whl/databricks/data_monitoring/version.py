"""Version of the data monitoring package."""
import json

import importlib.resources

version_data_str = importlib.resources.read_text("databricks.data_monitoring.resources",
                                                 "version.json")
version_data = json.loads(version_data_str)

VERSION = version_data["VERSION"]
TIMESTAMP = version_data["TIMESTAMP"]
INTERNAL_BUILD = f"{VERSION}+{TIMESTAMP}"
