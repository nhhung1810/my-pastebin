import os
from typing import Union, Optional, Iterable

from databricks.data_monitoring import metadata
from databricks.data_monitoring.analysis import Snapshot, TimeSeries, InferenceLog
from databricks.data_monitoring.context import Context
from databricks.data_monitoring.databricks_context import data_monitoring_api
from databricks.data_monitoring.metadata import MonitorCronSchedule
from databricks.data_monitoring.metrics import Metric


def _get_assets_directory(path: Optional[str] = None) -> str:
    """
    Returns the workspace directory where the monitoring assets
    (e.g. dashboard, queries) are stored.

    :param path: User-provided path for storing model monitoring assets
    :return: The directory where the monitoring assets are stored
    """
    if path is None:
        return os.path.join(
            "/Users",
            Context.user_name,
            "databricks_lakehouse_monitoring",
        )
    else:
        return path


@data_monitoring_api
def create_monitor(*,
                   table_name: str,
                   profile_type: Union[InferenceLog, TimeSeries, Snapshot],
                   output_schema_name: Optional[str] = None,
                   baseline_table_name: Optional[str] = None,
                   slicing_exprs: Optional[Iterable[str]] = None,
                   custom_metrics: Optional[Iterable[Metric]] = None,
                   schedule: Optional[MonitorCronSchedule] = None,
                   assets_dir: Optional[str] = None,
                   skip_builtin_dashboard: bool = False,
                   warehouse_id: Optional[str] = None) -> metadata.MonitorInfo:
    """
    Create a monitor asynchronously on a table (or view).

    :param table_name: Name of table (or view) in the Unity Catalog to be monitored.
        The name can take the following formats:

                        - ``"{catalog}.{schema}.{table}"``, or
                        - ``"{schema}.{table}"``, or
                        - ``"{table}"``.

        If the catalog or schema are not included, they will be inferred as the current
        catalog and schema name.
    :param profile_type: A :py:class:`databricks.lakehouse_monitoring.InferenceLog`
        or :py:class:`databricks.lakehouse_monitoring.TimeSeries`
        or :py:class:`databricks.lakehouse_monitoring.Snapshot` object
        which determines the type of metrics to be computed/monitored.
    :param output_schema_name: Name of the schema in which to create output tables. This can be in
        either ``"{schema}"`` or ``"{catalog}.{schema}"`` format. If not specified, this will fallback to the catalog
        and schema of the monitored table.
    :param baseline_table_name: Name of a table (or view) containing baseline data for comparison.
        The baseline table is expected to match the schema of the monitored table
        (except for timestamps where applicable). If columns are missing on
        either side then monitoring will use best-effort heuristics to compute
        the output metrics.
    :param slicing_exprs: List of column expressions to slice data with for
        targeted analysis. The data is grouped by each expression independently,
        resulting in a separate slice for each predicate and its complements. For
        example ``slicing_exprs=["col_1", "col_2 > 10"]`` will generate the
        following slices: two slices for ``col_2 > 10`` (True and False), and one
        slice per unique value in ``col_1``.
    :param custom_metrics: A list of :py:class:`databricks.lakehouse_monitoring.Metric` instances,
        representing custom metrics that will be computed and written to the output tables.
    :param schedule: A :py:class:`databricks.lakehouse_monitoring.MonitorCronSchedule` object
        that dictates the frequency at which the monitor refreshes its metrics.
    :param assets_dir: The absolute path to user-configurable workspace directory for
        storing monitoring assets. If provided, the assets will be created under:

            ``{assets_dir}/{table_name}``

        Otherwise, the assets will be stored under the default directory:

            ``/Users/{user_name}/databricks_lakehouse_monitoring/{table_name}``

        Note that this directory can exist anywhere, including ``/Shared/`` or other locations
        outside of the ``/Users/`` directory; this can be useful when configuring a production
        monitor intended to be shared within an organization.
    :param skip_builtin_dashboard: If True then the built-in dashboard will not be created.
    :param warehouse_id: The ID of the warehouse to use for dashboard creation. If no ID is
        provided, the first running warehouse will be used. Cannot be set if ``skip_builtin_dasbboard`` is set to True.
    :return: The info of the pending monitor.
    :rtype: :py:class:`databricks.lakehouse_monitoring.MonitorInfo`
    :raises LakehouseMonitoringError: Table is not in UC
    :raises LakehouseMonitoringError: Monitor already exists on table
    :raises LakehouseMonitoringError: Input arguments fail validation
    """
    return Context.service_client.create(
        table_name,
        metadata.CreateMonitorInfo(
            profile_type=profile_type,
            output_schema_name=output_schema_name,
            baseline_table_name=baseline_table_name,
            slicing_exprs=slicing_exprs,
            custom_metrics=custom_metrics,
            schedule=schedule,
            assets_dir=_get_assets_directory(assets_dir)),
        skip_builtin_dashboard=skip_builtin_dashboard,
        warehouse_id=warehouse_id)
