"""Fetches the data monitor information."""
from databricks.data_monitoring import display, metadata
from databricks.data_monitoring.context import Context
from databricks.data_monitoring.databricks_context import data_monitoring_api


@data_monitoring_api
def get_monitor(*, table_name: str) -> metadata.MonitorInfo:
    """
    Retrieve info for a monitor.

    :param table_name: The name of the monitored table.
    :return: Information about the monitor.
    :rtype: :py:class:`databricks.lakehouse_monitoring.MonitorInfo`
    :raises LakehouseMonitoringError: Monitor does not exist or if an error occurs
        while reading the information from the Lakehouse Monitoring service
    """
    info = Context.service_client.read(table_name)

    # Only display assets if monitor creation has completed.
    # Note that the metric tables will not exist until a refresh has completed.
    if info.status == metadata.MonitorStatus.ACTIVE:
        display.display_assets(info=info)

    return info
