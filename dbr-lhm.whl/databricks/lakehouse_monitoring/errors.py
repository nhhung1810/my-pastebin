class LakehouseMonitoringError(Exception):
    """
    An error from the Lakehouse Monitoring service.
    """
    pass
