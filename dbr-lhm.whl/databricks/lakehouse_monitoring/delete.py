from databricks.data_monitoring import display
from databricks.data_monitoring.context import Context
from databricks.data_monitoring.databricks_context import data_monitoring_api


@data_monitoring_api
def delete_monitor(*, table_name: str) -> None:
    """
    Delete a monitor on the given table.

    .. note::

        The monitor assets (profile tables and dashboard) are not deleted by this method.

    :param table_name: The name of the monitored table.
    :return: None
    :raises LakehouseMonitoringError: The monitor does not exist.
    """
    info = Context.service_client.read(table_name=table_name)
    Context.service_client.delete(table_name=table_name)
    display.display_lingering_assets(info)
