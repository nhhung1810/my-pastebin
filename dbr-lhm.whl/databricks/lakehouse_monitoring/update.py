import dataclasses
from typing import Any, Mapping

from databricks.data_monitoring import databricks_context, metadata
from databricks.data_monitoring.context import Context
from databricks.data_monitoring.databricks_context import data_monitoring_api
from databricks.lakehouse_monitoring import errors

_MUTABLE_PARAMS = {
    "profile_type", "baseline_table_name", "slicing_exprs", "custom_metrics", "schedule",
    "output_schema_name", "dashboard_id"
}


@data_monitoring_api
def update_monitor(*, table_name: str, updated_params: Mapping[str, Any]) -> metadata.MonitorInfo:
    """
    Update the parameters of an existing monitor on a table.

    .. note::

        Monitoring metrics will reflect the new configuration at the next time that a refresh runs. See
        :py:func:`databricks.lakehouse_monitoring.run_refresh` if you want to manually trigger a refresh.

    :param table_name: Name of monitored table
    :param updated_params: Dict of updated parameters and their new values. Any parameter set to ``None`` will be
      cleared in the configuration. The following parameters are recognized:

        - ``'profile_type'``:  one of :py:class:`databricks.lakehouse_monitoring.InferenceLog` or
          :py:class:`databricks.lakehouse_monitoring.TimeSeries` or :py:class:`databricks.lakehouse_monitoring.Snapshot`
        - ``'baseline_table_name'``: a non-empty table name or ``None``
        - ``'slicing_exprs'``: a non-empty ``Iterable[str]`` or ``None``
        - ``'custom_metrics'``: a non-empty ``Iterable`` of :py:class:`databricks.lakehouse_monitoring.Metric` or
          ``None``
        - ``'schedule'``: a non-empty :py:class:`databricks.lakehouse_monitoring.MonitorCronSchedule` or ``None``.
        - ``'output_schema_name'``: the two layer name of the schema in which to store the output metric tables.
        - ``'dashboard_id'``: A string with the id of the dashboard that should be associated with the monitor.

    :return: Updated information about the monitor.
    :rtype: :py:class:`databricks.lakehouse_monitoring.MonitorInfo`
    :raises LakehouseMonitoringError: Monitor does not exist
    :raises LakehouseMonitoringError: Caller does not have permissions to update
    :raises LakehouseMonitoringError: The parameters are invalid
    """
    # Check monitor existence and read metadata
    info = Context.service_client.read(table_name=table_name)

    # Validate that only the recognized update parameters are passed in
    invalid_params = set(updated_params.keys()) - _MUTABLE_PARAMS
    if len(invalid_params) > 0:
        raise errors.LakehouseMonitoringError(
            f"Received unrecognized update parameter(s) in `updated_params`: {invalid_params}.")

    databricks_context.preprocess_securables(updated_params)

    # Update params in metadata
    new_info = dataclasses.replace(info, **updated_params)
    return Context.service_client.update(table_name=table_name, info=new_info)
