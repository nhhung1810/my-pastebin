from typing import List

from databricks.data_monitoring import metadata
from databricks.data_monitoring.context import Context
from databricks.data_monitoring.databricks_context import data_monitoring_api


@data_monitoring_api
def run_refresh(*, table_name: str) -> metadata.RefreshInfo:
    """
    Queue a metric refresh for the input table. The refresh will execute in the background.

    :param table_name: Name of the monitored table.
    :return: Information for the refresh operation.
    :rtype: :py:class:`databricks.lakehouse_monitoring.RefreshInfo`
    """
    return Context.service_client.refresh(table_name=table_name)


@data_monitoring_api
def get_refresh(*, table_name: str, refresh_id: str) -> metadata.RefreshInfo:
    """
    Retrieve information for a specific refresh.

    :param table_name: Name of the monitored table.
    :param refresh_id: The id of the refresh.
    :return: Information about the refresh.
    :rtype: :py:class:`databricks.lakehouse_monitoring.RefreshInfo`
    :raises LakehouseMonitoringError: if there is an error retrieving the information
    """
    return Context.service_client.read_refresh(table_name=table_name, refresh_id=refresh_id)


@data_monitoring_api
def list_refreshes(*, table_name: str) -> List[metadata.RefreshInfo]:
    """
    Retrieve information on the most recent refreshes.

    :param table_name: Name of the monitored table.
    :return: Information about the refresh.
    :rtype: List[:py:class:`databricks.lakehouse_monitoring.RefreshInfo`]
    :raises LakehouseMonitoringError: if there is an error retrieving the information
    """
    return Context.service_client.list_refreshes(table_name=table_name)


@data_monitoring_api
def cancel_refresh(*, table_name: str, refresh_id: str) -> None:
    """
    Cancel a specific refresh.

    :param table_name: Name of the monitored table.
    :param refresh_id: The id of the refresh.
    :return: None
    :raises LakehouseMonitoringError: if the job is in a terminal state (e.g., failed, succeeded,
            etc.) or the refresh/monitor does not exist.
    """
    return Context.service_client.cancel_refresh(table_name=table_name, refresh_id=refresh_id)
